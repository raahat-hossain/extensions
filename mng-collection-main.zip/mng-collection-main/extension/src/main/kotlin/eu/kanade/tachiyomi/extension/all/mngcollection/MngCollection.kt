package eu.kanade.tachiyomi.extension.all.mngcollection

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import android.text.InputType
import androidx.preference.EditTextPreference
import androidx.preference.ListPreference
import androidx.preference.PreferenceScreen
import androidx.preference.SwitchPreferenceCompat
import eu.kanade.tachiyomi.extension.all.mngcollection.meta.ChapterList
import eu.kanade.tachiyomi.extension.all.mngcollection.meta.RemoteChapter
import eu.kanade.tachiyomi.extension.all.mngcollection.meta.SeriesMetadata
import eu.kanade.tachiyomi.extension.all.mngcollection.net.ArchiveCache
import eu.kanade.tachiyomi.extension.all.mngcollection.net.ArchiveInterceptor
import eu.kanade.tachiyomi.extension.all.mngcollection.net.R2Config
import eu.kanade.tachiyomi.extension.all.mngcollection.net.S3Client
import eu.kanade.tachiyomi.extension.all.mngcollection.net.S3Listing
import eu.kanade.tachiyomi.extension.all.mngcollection.net.S3Object
import eu.kanade.tachiyomi.extension.all.mngcollection.net.SigV4Interceptor
import eu.kanade.tachiyomi.extension.all.mngcollection.net.isAbsoluteUrl
import eu.kanade.tachiyomi.extension.all.mngcollection.util.NaturalOrder
import eu.kanade.tachiyomi.extension.all.mngcollection.util.chapterNumberOf
import eu.kanade.tachiyomi.extension.all.mngcollection.util.fileName
import eu.kanade.tachiyomi.extension.all.mngcollection.util.isArchiveKey
import eu.kanade.tachiyomi.extension.all.mngcollection.util.isHiddenKey
import eu.kanade.tachiyomi.extension.all.mngcollection.util.isImageKey
import eu.kanade.tachiyomi.extension.all.mngcollection.util.isUnsupportedArchiveKey
import eu.kanade.tachiyomi.network.GET
import eu.kanade.tachiyomi.source.ConfigurableSource
import eu.kanade.tachiyomi.source.model.Filter
import eu.kanade.tachiyomi.source.model.FilterList
import eu.kanade.tachiyomi.source.model.MangasPage
import eu.kanade.tachiyomi.source.model.Page
import eu.kanade.tachiyomi.source.model.SChapter
import eu.kanade.tachiyomi.source.model.SManga
import eu.kanade.tachiyomi.source.model.UpdateStrategy
import eu.kanade.tachiyomi.source.online.HttpSource
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import rx.Observable
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get
import java.io.IOException
import java.util.concurrent.Callable
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Serves a manga library that lives in a Cloudflare R2 bucket.
 *
 * The bucket is read through R2's S3-compatible API, so no server, worker or
 * generated index is needed: folders are series, their subfolders (or `.cbz`
 * files) are chapters, and the images inside are pages.
 */
class MngCollection : HttpSource(), ConfigurableSource {

    override val name = "MNG Collection"

    override val lang = "all"

    override val supportsLatest = true

    override val baseUrl: String
        get() = config()?.endpoint?.toString()?.trimEnd('/').orEmpty()

    // ------------------------------------------------------------------
    // Configuration
    // ------------------------------------------------------------------

    private val preferences: SharedPreferences by lazy {
        Injekt.get<Application>().getSharedPreferences("source_$id", 0x0000)
    }

    private fun config(): R2Config? {
        val endpoint = R2Config.parseEndpoint(preferences.string(PREF_ENDPOINT)) ?: return null
        val bucket = preferences.string(PREF_BUCKET).trim()
        val accessKeyId = preferences.string(PREF_ACCESS_KEY).trim()
        val secretAccessKey = preferences.string(PREF_SECRET_KEY).trim()
        if (bucket.isEmpty() || accessKeyId.isEmpty() || secretAccessKey.isEmpty()) return null

        return R2Config(
            endpoint = endpoint,
            bucket = bucket,
            accessKeyId = accessKeyId,
            secretAccessKey = secretAccessKey,
            region = preferences.string(PREF_REGION).ifBlank { DEFAULT_REGION },
            rootPrefix = R2Config.normalizePrefix(preferences.string(PREF_ROOT_PREFIX)),
            publicBaseUrl = R2Config.parsePublicBase(preferences.string(PREF_PUBLIC_BASE)),
        )
    }

    private fun requireConfig(): R2Config = config() ?: throw IOException(SETUP_MESSAGE)

    // ------------------------------------------------------------------
    // Networking
    // ------------------------------------------------------------------

    private val signer = SigV4Interceptor(::config)

    /** Signs S3 calls but does not understand archive page URLs. */
    private val signedClient: OkHttpClient by lazy {
        network.client.newBuilder().addInterceptor(signer).build()
    }

    private val archives: ArchiveCache by lazy { ArchiveCache(signedClient, ::config) }

    override val client: OkHttpClient by lazy {
        network.client.newBuilder()
            .addInterceptor(ArchiveInterceptor(archives))
            .addInterceptor(signer)
            .build()
    }

    private val s3: S3Client by lazy { S3Client(signedClient) }

    /** Covers are resolved per series, so a page of results is fetched concurrently. */
    private val coverPool: ExecutorService by lazy {
        Executors.newFixedThreadPool(COVER_THREADS) { runnable ->
            Thread(runnable, "mngcollection-cover").apply { isDaemon = true }
        }
    }

    // ------------------------------------------------------------------
    // Caches
    // ------------------------------------------------------------------

    private class Cached<T>(val value: T, val storedAt: Long)

    @Volatile
    private var seriesCache: Cached<List<Series>>? = null

    @Volatile
    private var recentCache: Cached<List<Series>>? = null

    /** Series folder listed one level deep — covers and metadata files. */
    private val shallowCache = LruCache<String, S3Listing>(64)

    /** Series folder listed recursively — chapters and their dates. */
    private val treeCache = LruCache<String, S3Listing>(8)

    private val coverCache = ConcurrentHashMap<String, String>()
    private val titleCache = ConcurrentHashMap<String, String>()

    private fun invalidateCaches() {
        seriesCache = null
        recentCache = null
        shallowCache.clear()
        treeCache.clear()
        coverCache.clear()
        titleCache.clear()
        archives.clear()
    }

    private fun <T> Cached<T>?.freshValue(): T? {
        val cached = this ?: return null
        val ttl = cacheTtlMs
        if (ttl > 0 && System.currentTimeMillis() - cached.storedAt > ttl) return null
        return cached.value
    }

    private val cacheTtlMs: Long
        get() = preferences.string(PREF_CACHE_TTL).toLongOrNull()?.times(1000L)
            ?: DEFAULT_CACHE_TTL_SECONDS * 1000L

    // ------------------------------------------------------------------
    // Browse
    // ------------------------------------------------------------------

    private data class Series(val name: String, val prefix: String)

    override fun fetchPopularManga(page: Int): Observable<MangasPage> =
        Observable.fromCallable { browse(page, "", FilterList()) }

    override fun fetchSearchManga(page: Int, query: String, filters: FilterList): Observable<MangasPage> =
        Observable.fromCallable { browse(page, query, filters) }

    override fun fetchLatestUpdates(page: Int): Observable<MangasPage> =
        Observable.fromCallable { paginate(recentSeries(requireConfig()), page) }

    private fun browse(page: Int, query: String, filters: FilterList): MangasPage {
        val config = requireConfig()
        var series = allSeries(config)

        if (query.isNotBlank()) {
            val needle = query.trim()
            series = series.filter { it.name.contains(needle, ignoreCase = true) }
        }
        val ascending = filters.filterIsInstance<SortFilter>()
            .firstOrNull()?.state?.ascending ?: true
        if (!ascending) series = series.asReversed()

        return paginate(series, page)
    }

    private fun paginate(series: List<Series>, page: Int): MangasPage {
        val from = (page - 1) * PAGE_SIZE
        val slice = series.drop(from).take(PAGE_SIZE)
        return MangasPage(withCovers(requireConfig(), slice), series.size > from + slice.size)
    }

    private fun allSeries(config: R2Config): List<Series> {
        seriesCache.freshValue()?.let { return it }

        val listing = s3.listAll(config, config.rootPrefix, DELIMITER)
        val series = listing.prefixes
            .map { Series(name = it.removePrefix(config.rootPrefix).trimEnd('/'), prefix = it) }
            .filter { it.name.isNotEmpty() && !it.name.startsWith(".") && !isExcludedSeriesName(it.name) }
            .sortedWith(compareBy(NaturalOrder) { it.name })

        if (series.isEmpty()) throw IOException(emptyLibraryMessage(config, listing))

        seriesCache = Cached(series, System.currentTimeMillis())
        return series
    }

    /**
     * Object listings come back in alphabetical order, never by date, so
     * "latest" means scanning the library and keeping the newest object per
     * series. The scan is capped to keep very large buckets usable.
     */
    private fun recentSeries(config: R2Config): List<Series> {
        recentCache.freshValue()?.let { return it }

        val maxPages = preferences.string(PREF_LATEST_PAGES).toIntOrNull()
            ?.coerceIn(1, 100) ?: DEFAULT_LATEST_PAGES
        val listing = s3.listAll(config, config.rootPrefix, delimiter = null, maxPages = maxPages)

        val newest = HashMap<String, Long>()
        for (obj in listing.objects) {
            if (isHiddenKey(obj.key)) continue
            val name = obj.key.removePrefix(config.rootPrefix).substringBefore('/', "")
            if (name.isEmpty() || isExcludedSeriesName(name)) continue
            val current = newest[name]
            if (current == null || obj.lastModified > current) newest[name] = obj.lastModified
        }

        val series = newest.entries
            .sortedByDescending { it.value }
            .map { Series(it.key, "${config.rootPrefix}${it.key}/") }

        if (series.isEmpty()) throw IOException(emptyLibraryMessage(config, listing))

        recentCache = Cached(series, System.currentTimeMillis())
        return series
    }

    private data class SeriesCard(val title: String, val coverUrl: String?)

    private fun withCovers(config: R2Config, series: List<Series>): List<SManga> {
        if (series.isEmpty()) return emptyList()

        val pending = series.map { entry ->
            coverPool.submit(Callable {
                runCatching {
                    val listing = shallowListing(config, entry.prefix)
                    val title = titleCache[entry.prefix] ?: displayTitle(
                        entry.name,
                        readMetadata(config, listing)?.title,
                    ).also { titleCache[entry.prefix] = it }
                    SeriesCard(title, coverUrl(config, entry.prefix, listing))
                }.getOrNull()
            })
        }
        return series.mapIndexed { index, entry ->
            val card = runCatching { pending[index].get() }.getOrNull()
            SManga.create().apply {
                url = entry.prefix
                title = card?.title ?: entry.name
                thumbnail_url = card?.coverUrl
                update_strategy = UpdateStrategy.ALWAYS_UPDATE
            }
        }
    }

    // ------------------------------------------------------------------
    // Details
    // ------------------------------------------------------------------

    override fun fetchMangaDetails(manga: SManga): Observable<SManga> = Observable.fromCallable {
        val config = requireConfig()
        val listing = shallowListing(config, manga.url)
        val metadata = readMetadata(config, listing)

        SManga.create().apply {
            url = manga.url
            title = displayTitle(manga.url.fileName(), metadata?.title)
            author = metadata?.author
            artist = metadata?.artist
            description = metadata?.description
            genre = metadata?.genre
            status = metadata?.status ?: SManga.UNKNOWN
            thumbnail_url = runCatching { coverUrl(config, manga.url) }.getOrNull()
            update_strategy = UpdateStrategy.ALWAYS_UPDATE
            initialized = true
        }
    }

    private fun readMetadata(config: R2Config, listing: S3Listing): SeriesMetadata? {
        val byName = listing.objects.associateBy { it.key.fileName().lowercase() }

        byName[SeriesMetadata.DETAILS_JSON]?.let { obj ->
            fetchText(config, obj)?.let { text ->
                SeriesMetadata.fromDetailsJson(text)?.let { return it }
            }
        }
        byName[SeriesMetadata.COMIC_INFO_XML]?.let { obj ->
            fetchText(config, obj)?.let { text ->
                SeriesMetadata.fromComicInfo(text)?.let { return it }
            }
        }
        return null
    }

    private fun fetchText(config: R2Config, obj: S3Object): String? {
        if (obj.size > MAX_METADATA_BYTES) return null
        return runCatching {
            signedClient.newCall(GET(config.objectUrl(obj.key), headers)).execute().use { response ->
                if (response.isSuccessful) response.body!!.string() else null
            }
        }.getOrNull()
    }

    private fun coverUrl(config: R2Config, seriesPrefix: String): String? =
        coverUrl(config, seriesPrefix, shallowListing(config, seriesPrefix))

    private fun coverUrl(config: R2Config, seriesPrefix: String, listing: S3Listing): String? {
        coverCache[seriesPrefix]?.let { return it }

        val directImages = listing.objects.filter { isImageKey(it.key) && it.key.isChildOf(seriesPrefix) }

        val url = directImages.firstOrNull { it.key.isCoverFile() }?.let { config.imageUrl(it.key).toString() }
            ?: directImages.minWithOrNull(compareBy(NaturalOrder) { it.key })
                ?.let { config.imageUrl(it.key).toString() }
            ?: firstPageUrl(config, listing)

        if (url != null) coverCache[seriesPrefix] = url
        return url
    }

    /** Falls back to the opening page of the first chapter when there is no `cover.*`. */
    private fun firstPageUrl(config: R2Config, listing: S3Listing): String? {
        listing.prefixes.minWithOrNull(NaturalOrder)?.let { firstFolder ->
            val page = s3.listAll(config, firstFolder, delimiter = null, maxPages = 1)
                .objects
                .filter { isImageKey(it.key) }
                .minWithOrNull(compareBy(NaturalOrder) { it.key })
            if (page != null) return config.imageUrl(page.key).toString()
        }

        val archive = listing.objects
            .filter { isArchiveKey(it.key) }
            .minWithOrNull(compareBy(NaturalOrder) { it.key })
            ?: return null

        val entry = archives.zipFor(archive.key).entries()
            .filter { isImageKey(it.name) }
            .minWithOrNull(compareBy(NaturalOrder) { it.name })
            ?: return null

        return ArchiveInterceptor.pageUrl(archive.key, entry.name)
    }

    // ------------------------------------------------------------------
    // Chapters
    // ------------------------------------------------------------------

    override fun fetchChapterList(manga: SManga): Observable<List<SChapter>> = Observable.fromCallable {
        val config = requireConfig()
        val seriesPrefix = manga.url
        val tree = treeListing(config, seriesPrefix)
        val seriesName = seriesPrefix.fileName()

        // Folder chapters, keyed by the deepest folder that actually holds
        // images, so Volume/Chapter nesting works without extra configuration.
        val folderDates = LinkedHashMap<String, Long>()
        val archiveObjects = mutableListOf<S3Object>()
        val looseImages = mutableListOf<S3Object>()
        var unsupported = 0

        for (obj in tree.objects) {
            if (isHiddenKey(obj.key)) continue
            when {
                isArchiveKey(obj.key) -> archiveObjects += obj
                isUnsupportedArchiveKey(obj.key) -> unsupported++
                !isImageKey(obj.key) -> Unit
                obj.key.isChildOf(seriesPrefix) -> looseImages += obj
                else -> {
                    val folder = "${obj.key.substringBeforeLast('/')}/"
                    val previous = folderDates[folder]
                    if (previous == null || obj.lastModified > previous) {
                        folderDates[folder] = obj.lastModified
                    }
                }
            }
        }

        val chapters = mutableListOf<RawChapter>()

        folderDates.forEach { (folder, date) ->
            chapters += RawChapter(
                url = folder,
                label = folder.removePrefix(seriesPrefix).trimEnd('/').replace("/", " – "),
                date = date,
            )
        }
        archiveObjects.forEach { obj ->
            chapters += RawChapter(
                url = obj.key,
                label = obj.key.removePrefix(seriesPrefix).substringBeforeLast('.').replace("/", " – "),
                date = obj.lastModified,
            )
        }
        // A series folder holding images directly is one chapter — but a folder
        // holding nothing except its cover is not a chapter at all.
        val flatPages = pagesOf(looseImages).filterNot { it.key.isCoverFile() }
        if (chapters.isEmpty() && flatPages.isNotEmpty()) {
            chapters += RawChapter(
                url = seriesPrefix,
                label = seriesName,
                date = flatPages.maxOfOrNull { it.lastModified } ?: 0L,
            )
        }

        // Chapters that live outside the bucket, declared in chapters.json.
        var hasChapterList = false
        tree.objects.firstOrNull { it.key.fileName().equals(ChapterList.FILE_NAME, true) }
            ?.let { declared ->
                hasChapterList = true
                fetchText(config, declared)?.let { text ->
                    ChapterList.parse(text).forEach { remote ->
                        chapters += RawChapter(
                            url = remote.archiveUrl
                                // A page list cannot fit in a chapter url, so point
                                // back at the file it came from and look it up again.
                                ?: "$seriesPrefix${ChapterList.FILE_NAME}$REMOTE_CHAPTER_MARKER${remote.name}",
                            label = remote.name,
                            date = remote.dateUpload,
                            number = remote.number,
                            scanlator = remote.scanlator,
                        )
                    }
                }
            }

        if (chapters.isEmpty()) {
            throw IOException(emptySeriesMessage(seriesName, unsupported, hasChapterList))
        }

        chapters
            .distinctBy { it.url }
            .sortedWith(compareBy(NaturalOrder) { it.label })
            .mapIndexed { index, raw ->
                SChapter.create().apply {
                    url = raw.url
                    name = raw.label
                    date_upload = raw.date
                    scanlator = raw.scanlator
                    chapter_number = raw.number
                        ?: chapterNumberOf(raw.label, seriesName).takeIf { it >= 0f }
                        ?: (index + 1).toFloat()
                }
            }
            .asReversed()
    }

    private data class RawChapter(
        val url: String,
        val label: String,
        val date: Long,
        val number: Float? = null,
        val scanlator: String? = null,
    )

    // ------------------------------------------------------------------
    // Pages
    // ------------------------------------------------------------------

    override fun fetchPageList(chapter: SChapter): Observable<List<Page>> = Observable.fromCallable {
        val config = requireConfig()

        val pages = when {
            // Pages listed one by one in chapters.json, which cannot be carried
            // in the chapter url — reread the file and look the chapter up.
            chapter.url.contains(REMOTE_CHAPTER_MARKER) -> {
                val (file, name) = chapter.url.split(REMOTE_CHAPTER_MARKER, limit = 2)
                    .let { it[0] to it.getOrElse(1) { "" } }
                declaredChapter(config, file, name).pages.mapIndexed { index, url ->
                    Page(index, "", url)
                }
            }

            // An archive anywhere else on the internet.
            isAbsoluteUrl(chapter.url) -> archivePages(chapter.url)

            // A folder of images in the bucket.
            chapter.url.endsWith("/") -> {
                val images = s3.listAll(config, chapter.url, delimiter = null)
                    .objects
                    .filter { isImageKey(it.key) && it.key.isChildOf(chapter.url) }
                pagesOf(images).mapIndexed { index, obj ->
                    Page(index, "", config.imageUrl(obj.key).toString())
                }
            }

            // An archive stored in the bucket.
            else -> archivePages(chapter.url)
        }

        if (pages.isEmpty()) throw IOException("No images found in \"${chapter.url.fileName()}\".")
        pages
    }

    /** Pages of an archive, whether it lives in the bucket or on another host. */
    private fun archivePages(target: String): List<Page> =
        archives.zipFor(target).entries()
            .filter { isImageKey(it.name) && !isHiddenKey(it.name) }
            .sortedWith(compareBy(NaturalOrder) { it.name })
            .mapIndexed { index, entry ->
                Page(index, "", ArchiveInterceptor.pageUrl(target, entry.name))
            }

    private fun declaredChapter(config: R2Config, file: String, name: String): RemoteChapter {
        val obj = s3.listAll(config, file, delimiter = null).objects
            .firstOrNull { it.key == file }
            ?: throw IOException("$file is missing, so \"$name\" cannot be opened.")
        val text = fetchText(config, obj)
            ?: throw IOException("Could not read $file.")
        return ChapterList.parse(text).firstOrNull { it.name == name }
            ?: throw IOException("\"$name\" is no longer listed in $file.")
    }

    /**
     * Sorts images into reading order and drops the series cover, which sits
     * beside the pages in a flat layout but is not part of the chapter.
     */
    private fun pagesOf(images: List<S3Object>): List<S3Object> {
        val sorted = images.sortedWith(compareBy(NaturalOrder) { it.key })
        if (sorted.size <= 1) return sorted
        return sorted.filterNot { it.key.isCoverFile() }
    }

    // ------------------------------------------------------------------
    // Listing helpers
    // ------------------------------------------------------------------

    private fun shallowListing(config: R2Config, seriesPrefix: String): S3Listing =
        shallowCache.get(seriesPrefix) { s3.listAll(config, seriesPrefix, DELIMITER) }

    private fun treeListing(config: R2Config, seriesPrefix: String): S3Listing =
        treeCache.get(seriesPrefix) { s3.listAll(config, seriesPrefix, delimiter = null) }

    private fun String.isChildOf(prefix: String): Boolean =
        startsWith(prefix) && !removePrefix(prefix).contains('/')

    private fun String.isCoverFile(): Boolean =
        fileName().substringBeforeLast('.').equals("cover", ignoreCase = true)

    private fun emptyLibraryMessage(config: R2Config, listing: S3Listing): String {
        val where = if (config.rootPrefix.isEmpty()) {
            "bucket \"${config.bucket}\""
        } else {
            "\"${config.rootPrefix}\" in bucket \"${config.bucket}\""
        }
        return if (listing.objects.isEmpty()) {
            "No files found in $where. Upload your library as " +
                "<series>/<chapter>/<page>.jpg, then pull to refresh."
        } else {
            "No series folders found in $where — the files there are not inside a " +
                "series folder. Expected <series>/<chapter>/<page>.jpg."
        }
    }

    private fun emptySeriesMessage(
        seriesName: String,
        unsupported: Int,
        hasChapterList: Boolean,
    ): String = when {
        // The file is there but gave us nothing — almost always empty, invalid
        // JSON, or entries missing the one field that matters.
        hasChapterList ->
            "\"$seriesName\" has a ${ChapterList.FILE_NAME} but no readable chapters in it. " +
                "Check the file is not empty and is valid JSON, and that every entry has a " +
                "\"url\" (an archive) or \"pages\" (a list of image addresses)."
        unsupported > 0 ->
            "\"$seriesName\" only contains archive formats this source cannot open " +
                "($unsupported file(s)). Convert them to .cbz, or upload the pages as loose images."
        else ->
            "No chapters found in \"$seriesName\". Expected chapter folders of images, .cbz files, " +
                "or a ${ChapterList.FILE_NAME} listing chapters hosted elsewhere."
    }

    // ------------------------------------------------------------------
    // Filters
    // ------------------------------------------------------------------

    private class SortFilter :
        Filter.Sort("Sort", arrayOf("Title"), Filter.Sort.Selection(0, ascending = true))

    override fun getFilterList() = FilterList(
        Filter.Header("Search matches folder names in your bucket."),
        SortFilter(),
    )

    // ------------------------------------------------------------------
    // Settings
    // ------------------------------------------------------------------

    override fun setupPreferenceScreen(screen: PreferenceScreen) {
        val context = screen.context

        screen.addPreference(
            textPreference(
                context,
                key = PREF_ENDPOINT,
                title = "Account ID or S3 endpoint",
                dialogMessage = "Your Cloudflare account id, or the full S3 endpoint " +
                    "(https://<account>.r2.cloudflarestorage.com).",
            ),
        )
        screen.addPreference(
            textPreference(
                context,
                key = PREF_BUCKET,
                title = "Bucket name",
                dialogMessage = "The R2 bucket holding your library.",
            ),
        )
        screen.addPreference(
            textPreference(
                context,
                key = PREF_ACCESS_KEY,
                title = "Access Key ID",
                dialogMessage = "From an R2 API token. \"Object Read only\" permission is enough.",
            ),
        )
        screen.addPreference(
            textPreference(
                context,
                key = PREF_SECRET_KEY,
                title = "Secret Access Key",
                dialogMessage = "Shown once when the R2 API token is created.",
                password = true,
            ),
        )
        screen.addPreference(
            textPreference(
                context,
                key = PREF_ROOT_PREFIX,
                title = "Library folder (optional)",
                dialogMessage = "Folder inside the bucket that holds the series, e.g. \"manga\". " +
                    "Leave empty if the series folders sit at the bucket root.",
                placeholder = "Bucket root",
            ),
        )
        screen.addPreference(
            textPreference(
                context,
                key = PREF_PUBLIC_BASE,
                title = "Public image URL (optional)",
                dialogMessage = "A public r2.dev address or custom domain for this bucket. When " +
                    "set, images load from it instead of being signed one by one, which is " +
                    "faster and cheaper. Listing still uses the API token.",
                placeholder = "Not set — images load over the signed API",
            ),
        )
        screen.addPreference(
            textPreference(
                context,
                key = PREF_REGION,
                title = "Region",
                dialogMessage = "Leave as \"auto\" unless your bucket needs a specific region.",
                default = DEFAULT_REGION,
            ),
        )

        val ttlLabels = arrayOf("1 minute", "5 minutes", "15 minutes", "1 hour", "Never cache")
        val ttlValues = arrayOf("60", "300", "900", "3600", "0")
        val ttlDefault = DEFAULT_CACHE_TTL_SECONDS.toString()
        fun ttlLabelFor(value: String?): String =
            ttlLabels.getOrElse(ttlValues.indexOf(value ?: ttlDefault)) { "$value seconds" }

        screen.addPreference(
            ListPreference(context).apply {
                key = PREF_CACHE_TTL
                title = "Re-read the bucket every"
                entries = arrayOf<CharSequence>(*ttlLabels)
                entryValues = arrayOf<CharSequence>(*ttlValues)
                setDefaultValue(ttlDefault)
                summary = ttlLabelFor(preferences.getString(PREF_CACHE_TTL, ttlDefault))

                setOnPreferenceChangeListener { _, newValue ->
                    summary = ttlLabelFor(newValue as? String)
                    invalidateCaches()
                    true
                }
            },
        )

        screen.addPreference(
            textPreference(
                context,
                key = PREF_LATEST_PAGES,
                title = "Latest updates scan limit",
                dialogMessage = "How many 1000-object pages to scan when building the Latest " +
                    "listing. Raise it if a large library looks incomplete there.",
                default = DEFAULT_LATEST_PAGES.toString(),
                numeric = true,
            ),
        )

        screen.addPreference(
            SwitchPreferenceCompat(context).apply {
                key = PREF_CLEAR_CACHE
                title = "Clear cached listings"
                summary = "Flip this to forget what was read from the bucket and load it again."
                setDefaultValue(false)
                setOnPreferenceChangeListener { _, _ ->
                    invalidateCaches()
                    true
                }
            },
        )
    }

    /**
     * extensions-lib's `androidx.preference` stubs have no `SummaryProvider`, so
     * summaries are written by hand and refreshed as the value changes.
     */
    private fun textPreference(
        context: Context,
        key: String,
        title: String,
        dialogMessage: String,
        default: String = "",
        placeholder: String = "Not set",
        password: Boolean = false,
        numeric: Boolean = false,
    ): EditTextPreference = EditTextPreference(context).apply {
        this.key = key
        this.title = title
        this.dialogTitle = title
        this.dialogMessage = dialogMessage
        setDefaultValue(default)

        fun describe(value: String?): String = when {
            value.isNullOrBlank() -> placeholder
            password -> "•".repeat(12)
            else -> value
        }

        summary = describe(preferences.getString(key, default))

        if (password || numeric) {
            setOnBindEditTextListener { editText ->
                editText.inputType = if (password) {
                    InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                } else {
                    InputType.TYPE_CLASS_NUMBER
                }
            }
        }

        setOnPreferenceChangeListener { _, newValue ->
            summary = describe(newValue as? String)
            invalidateCaches()
            true
        }
    }

    private fun SharedPreferences.string(key: String): String = getString(key, "").orEmpty()

    // ------------------------------------------------------------------
    // Unused HttpSource plumbing
    //
    // Every request this source makes needs several round trips against the S3
    // API, so the fetch* methods above are overridden directly and the
    // one-request-in, one-response-out hooks are never called.
    // ------------------------------------------------------------------

    private fun unsupported(): Nothing =
        throw UnsupportedOperationException("Not used by this source.")

    override fun popularMangaRequest(page: Int): Request = unsupported()
    override fun popularMangaParse(response: Response): MangasPage = unsupported()
    override fun latestUpdatesRequest(page: Int): Request = unsupported()
    override fun latestUpdatesParse(response: Response): MangasPage = unsupported()
    override fun searchMangaRequest(page: Int, query: String, filters: FilterList): Request = unsupported()
    override fun searchMangaParse(response: Response): MangasPage = unsupported()
    override fun mangaDetailsParse(response: Response): SManga = unsupported()
    override fun chapterListParse(response: Response): List<SChapter> = unsupported()
    override fun pageListParse(response: Response): List<Page> = unsupported()
    override fun imageUrlParse(response: Response): String = unsupported()

    // There is no web page to open: storage URLs need a signature, so a browser
    // only ever gets a 401. Reporting no url keeps the app from showing a long,
    // unusable link (and the account id with it) on the details screen.
    //
    // Empty rather than an exception on purpose — some apps catch a throwing
    // getMangaUrl and hide the row, but others would surface the crash.
    override fun getMangaUrl(manga: SManga): String = ""

    override fun getChapterUrl(chapter: SChapter): String = ""

    private companion object {
        const val PAGE_SIZE = 30
        const val COVER_THREADS = 6
        const val DELIMITER = "/"
        const val DEFAULT_REGION = "auto"
        const val DEFAULT_CACHE_TTL_SECONDS = 300L
        const val DEFAULT_LATEST_PAGES = 10
        const val MAX_METADATA_BYTES = 1024L * 1024

        /** Separates a chapters.json path from the chapter name declared in it. */
        const val REMOTE_CHAPTER_MARKER = "#chapter="

        const val PREF_ENDPOINT = "r2_endpoint"
        const val PREF_BUCKET = "r2_bucket"
        const val PREF_ACCESS_KEY = "r2_access_key_id"
        const val PREF_SECRET_KEY = "r2_secret_access_key"
        const val PREF_ROOT_PREFIX = "r2_root_prefix"
        const val PREF_PUBLIC_BASE = "r2_public_base_url"
        const val PREF_REGION = "r2_region"
        const val PREF_CACHE_TTL = "r2_cache_ttl"
        const val PREF_LATEST_PAGES = "r2_latest_pages"
        const val PREF_CLEAR_CACHE = "r2_clear_cache"

        const val SETUP_MESSAGE =
            "This source is not set up yet. Open its settings and fill in your Cloudflare " +
                "account id, bucket name, and R2 API token (Access Key ID + Secret Access Key)."
    }
}

/** The upload staging folder is not a manga series and must stay out of the source. */
internal fun isExcludedSeriesName(name: String): Boolean = name.equals("upload", ignoreCase = true)

internal fun displayTitle(folderName: String, metadataTitle: String?): String =
    metadataTitle?.trim()?.takeIf { it.isNotEmpty() } ?: folderName

/** Small synchronized LRU used for the bucket listings. */
private class LruCache<K : Any, V : Any>(private val maxSize: Int) {
    private val entries = object : LinkedHashMap<K, V>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<K, V>) = size > maxSize
    }

    fun get(key: K, load: () -> V): V {
        synchronized(entries) { entries[key] }?.let { return it }
        val value = load()
        synchronized(entries) { entries[key] = value }
        return value
    }

    fun clear() = synchronized(entries) { entries.clear() }
}
