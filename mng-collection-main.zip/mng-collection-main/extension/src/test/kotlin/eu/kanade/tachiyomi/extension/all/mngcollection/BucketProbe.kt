package eu.kanade.tachiyomi.extension.all.mngcollection

import eu.kanade.tachiyomi.extension.all.mngcollection.meta.ChapterList
import eu.kanade.tachiyomi.extension.all.mngcollection.meta.SeriesMetadata
import eu.kanade.tachiyomi.extension.all.mngcollection.net.R2Config
import eu.kanade.tachiyomi.extension.all.mngcollection.net.RemoteZip
import eu.kanade.tachiyomi.extension.all.mngcollection.net.S3Client
import eu.kanade.tachiyomi.extension.all.mngcollection.net.S3Listing
import eu.kanade.tachiyomi.extension.all.mngcollection.net.S3Object
import eu.kanade.tachiyomi.extension.all.mngcollection.net.SigV4Interceptor
import eu.kanade.tachiyomi.extension.all.mngcollection.util.NaturalOrder
import eu.kanade.tachiyomi.extension.all.mngcollection.util.chapterNumberOf
import eu.kanade.tachiyomi.extension.all.mngcollection.util.fileName
import eu.kanade.tachiyomi.extension.all.mngcollection.util.isArchiveKey
import eu.kanade.tachiyomi.extension.all.mngcollection.util.isHiddenKey
import eu.kanade.tachiyomi.extension.all.mngcollection.util.isImageKey
import eu.kanade.tachiyomi.extension.all.mngcollection.util.isUnsupportedArchiveKey
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.junit.Assume.assumeTrue
import org.junit.Test
import java.util.concurrent.TimeUnit

/**
 * Not a unit test — a diagnostic you point at a real bucket, using the same
 * signing, listing and archive code the extension runs on the device. It
 * reports what the source would show and calls out layout problems.
 *
 * Skipped unless the credentials are supplied through the environment:
 *
 *     R2_ACCOUNT_ID=... R2_BUCKET=... R2_ACCESS_KEY_ID=... R2_SECRET_ACCESS_KEY=... \
 *       ./gradlew :extension:testReleaseUnitTest --tests '*BucketProbe*'
 *
 * or just run `scripts/probe-bucket.sh`, which prompts for the secret.
 */
class BucketProbe {

    private val problems = mutableListOf<String>()
    private val notes = mutableListOf<String>()

    @Test
    fun probe() {
        val endpointRaw = env("R2_ENDPOINT") ?: env("R2_ACCOUNT_ID")
        val bucket = env("R2_BUCKET")
        val accessKeyId = env("R2_ACCESS_KEY_ID")
        val secretAccessKey = env("R2_SECRET_ACCESS_KEY")

        assumeTrue(
            "Skipped: set R2_ACCOUNT_ID (or R2_ENDPOINT), R2_BUCKET, R2_ACCESS_KEY_ID " +
                "and R2_SECRET_ACCESS_KEY to run this probe.",
            endpointRaw != null && bucket != null && accessKeyId != null && secretAccessKey != null,
        )

        val endpoint = R2Config.parseEndpoint(endpointRaw!!)
        requireNotNull(endpoint) { "Could not read an endpoint from \"$endpointRaw\"." }

        val config = R2Config(
            endpoint = endpoint,
            bucket = bucket!!,
            accessKeyId = accessKeyId!!,
            secretAccessKey = secretAccessKey!!,
            region = env("R2_REGION") ?: "auto",
            rootPrefix = R2Config.normalizePrefix(env("R2_ROOT_PREFIX").orEmpty()),
            publicBaseUrl = env("R2_PUBLIC_BASE_URL")?.let(R2Config::parsePublicBase),
        )

        val client = OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .addInterceptor(SigV4Interceptor { config })
            .build()
        val s3 = S3Client(client)

        // Credentials are never echoed back, only what they unlock.
        heading("Configuration")
        say("endpoint       ${config.endpoint}")
        say("bucket         ${config.bucket}")
        say("library folder ${config.rootPrefix.ifEmpty { "(bucket root)" }}")
        say("public origin  ${config.publicBaseUrl ?: "(none — images load over the signed API)"}")
        say("access key     ${accessKeyId.take(4)}… (${accessKeyId.length} chars)")

        heading("1. Connect and authenticate")
        val root = try {
            s3.listAll(config, config.rootPrefix, "/")
        } catch (e: Exception) {
            say("FAILED: ${e.message}")
            throw AssertionError("Could not list the bucket — see the message above.", e)
        }
        say("OK — the token can list this bucket.")

        heading("2. Series")
        val series = root.prefixes
            .map { it.removePrefix(config.rootPrefix).trimEnd('/') to it }
            .filter { it.first.isNotEmpty() && !it.first.startsWith(".") }
            .sortedWith(compareBy(NaturalOrder) { it.first })

        if (series.isEmpty()) {
            problems += if (root.objects.isEmpty()) {
                "No files at all under ${describeRoot(config)}. Nothing to show."
            } else {
                "Found ${root.objects.size} file(s) directly under ${describeRoot(config)} but no " +
                    "series folders. Expected <series>/<chapter>/<page>.jpg. " +
                    "If your series live in a subfolder, set R2_ROOT_PREFIX / the " +
                    "\"Library folder\" setting to it."
            }
            root.objects.take(5).forEach { say("  loose file: ${it.key}") }
            report()
            return
        }

        say("${series.size} series found. First few:")
        series.take(10).forEach { say("  • ${it.first}") }

        heading("3. Series contents")
        var inspected = 0
        var withCover = 0
        var withMetadata = 0

        for ((name, prefix) in series.take(MAX_SERIES_INSPECTED)) {
            val listing = s3.listAll(config, prefix, "/")
            inspected++

            val cover = listing.objects.firstOrNull {
                isImageKey(it.key) && it.key.fileName().substringBeforeLast('.').equals("cover", true)
            }
            val metadataFile = listing.objects.firstOrNull {
                it.key.fileName().lowercase() in setOf(
                    SeriesMetadata.DETAILS_JSON, SeriesMetadata.COMIC_INFO_XML,
                )
            }
            val archives = listing.objects.filter { isArchiveKey(it.key) && !isHiddenKey(it.key) }
            val unsupported = listing.objects.filter { isUnsupportedArchiveKey(it.key) }

            if (cover != null) withCover++
            if (metadataFile != null) withMetadata++

            say(
                "  • $name — ${listing.prefixes.size} chapter folder(s), ${archives.size} archive(s)" +
                    (if (cover != null) ", cover" else "") +
                    (if (metadataFile != null) ", ${metadataFile.key.fileName()}" else ""),
            )

            val declaredChapters = listing.objects
                .firstOrNull { it.key.fileName().equals(ChapterList.FILE_NAME, true) }
                ?.let { declared -> verifyChapterList(client, config, declared, name) }
                ?: 0

            if (unsupported.isNotEmpty()) {
                problems += "\"$name\" contains ${unsupported.size} file(s) in a format that cannot " +
                    "be opened (${unsupported.take(3).joinToString { it.key.fileName() }}). Convert to .cbz."
            }
            if (listing.prefixes.isEmpty() && archives.isEmpty() && declaredChapters == 0) {
                val loose = listing.objects.count { isImageKey(it.key) }
                if (loose > 0) {
                    notes += "\"$name\" has images directly inside it; it will show as a single chapter."
                } else {
                    problems += "\"$name\" has no chapter folders, no archives and no images."
                }
            }
            metadataFile?.let { verifyMetadata(client, config, it) }
        }
        say("Inspected $inspected series: $withCover with a cover, $withMetadata with metadata.")

        heading("4. Open the first chapter")
        val (firstName, firstPrefix) = series.first()
        val firstListing = s3.listAll(config, firstPrefix, "/")
        val pages = firstPagesOf(config, client, s3, firstListing, firstName)

        if (pages == null) {
            problems += "Could not find any pages in the first series (\"$firstName\")."
        } else {
            say("\"$firstName\" → ${pages.label}: ${pages.count} page(s)")
            say("first page: ${pages.firstUrl}")
            if (pages.count == 0) problems += "\"${pages.label}\" contains no images."
        }

        // When a series uses both layouts, check the archive too — range
        // requests and inflating are the part most likely to misbehave.
        val archive = firstListing.objects
            .filter { isArchiveKey(it.key) && !isHiddenKey(it.key) }
            .minWithOrNull(compareBy(NaturalOrder) { it.key })
        if (archive != null && firstListing.prefixes.isNotEmpty()) {
            heading("4b. Open an archive chapter")
            val zip = RemoteZip(client, config.imageUrl(archive.key))
            val entries = zip.entries()
                .filter { isImageKey(it.name) && !isHiddenKey(it.name) }
                .sortedWith(compareBy(NaturalOrder) { it.name })
            say("${archive.key.fileName()}: ${entries.size} page(s)")
            val entry = entries.firstOrNull()
            if (entry == null) {
                problems += "${archive.key.fileName()} contains no images."
            } else {
                val bytes = zip.read(entry)
                say("read ${entry.name}: ${bytes.size} bytes")
                if (!looksLikeAnImage(bytes)) {
                    problems += "\"${entry.name}\" inside ${archive.key.fileName()} did not " +
                        "decompress to image bytes."
                }
            }
        }

        heading("5. Download a page")
        if (pages?.probeUrl != null) {
            val request = Request.Builder().url(pages.probeUrl)
                .header("Range", "bytes=0-2047")
                .build()
            client.newCall(request).execute().use { response ->
                val bytes = response.body!!.bytes()
                if (response.isSuccessful) {
                    say("OK — HTTP ${response.code}, ${bytes.size} bytes, ${response.header("Content-Type")}")
                    if (!looksLikeAnImage(bytes)) {
                        problems += "The first page did not start with recognisable image bytes."
                    }
                } else {
                    problems += "Fetching a page failed with HTTP ${response.code}."
                }
            }
        } else if (pages != null) {
            say("Page comes from an archive; already read successfully above.")
        }

        config.publicBaseUrl?.let { verifyPublicOrigin(client, config, pages) }

        report()
    }

    // ------------------------------------------------------------------

    private class FirstPages(
        val label: String,
        val count: Int,
        val firstUrl: String,
        /** Only set for loose files; archive pages are already proven by reading them. */
        val probeUrl: String?,
    )

    private fun firstPagesOf(
        config: R2Config,
        client: OkHttpClient,
        s3: S3Client,
        listing: S3Listing,
        seriesName: String,
    ): FirstPages? {
        val folder = listing.prefixes.minWithOrNull(NaturalOrder)
        if (folder != null) {
            val images = s3.listAll(config, folder, null).objects
                .filter { isImageKey(it.key) && !isHiddenKey(it.key) }
                .sortedWith(compareBy(NaturalOrder) { it.key })
            val label = folder.fileName()
            sayChapterNumber(label, seriesName)
            val first = images.firstOrNull() ?: return FirstPages(label, 0, "(none)", null)
            val url = config.imageUrl(first.key).toString()
            return FirstPages(label, images.size, url, url)
        }

        val archive = listing.objects
            .filter { isArchiveKey(it.key) && !isHiddenKey(it.key) }
            .minWithOrNull(compareBy(NaturalOrder) { it.key })
            ?: return null

        val label = archive.key.fileName()
        sayChapterNumber(label, seriesName)

        val zip = RemoteZip(client, config.imageUrl(archive.key))
        val entries = zip.entries()
            .filter { isImageKey(it.name) && !isHiddenKey(it.name) }
            .sortedWith(compareBy(NaturalOrder) { it.name })
        val first = entries.firstOrNull() ?: return FirstPages(label, 0, "(none)", null)

        val bytes = zip.read(first)
        say("read ${first.name} from the archive: ${bytes.size} bytes")
        if (!looksLikeAnImage(bytes)) {
            problems += "\"${first.name}\" inside $label did not decompress to image bytes."
        }
        return FirstPages(label, entries.size, "${archive.key} → ${first.name}", null)
    }

    private fun sayChapterNumber(label: String, seriesName: String) {
        val number = chapterNumberOf(label, seriesName)
        if (number < 0f) {
            notes += "No chapter number could be read from \"$label\"; the app will order it by name."
        } else {
            say("chapter number read from \"$label\": $number")
        }
    }

    /** Chapters hosted outside the bucket, declared in chapters.json. Returns how many. */
    private fun verifyChapterList(
        client: OkHttpClient,
        config: R2Config,
        obj: S3Object,
        seriesName: String,
    ): Int {
        val key = obj.key
        if (obj.size == 0L) {
            problems += "$key is empty (0 bytes). It needs a JSON list of chapters, each with a " +
                "\"url\" or \"pages\"."
            return 0
        }
        val body = client.newCall(Request.Builder().url(config.objectUrl(key)).build())
            .execute().use { if (it.isSuccessful) it.body!!.string() else null }
        if (body == null) {
            problems += "Could not download $key."
            return 0
        }

        val declared = ChapterList.parse(body)
        if (declared.isEmpty()) {
            problems += "$key declares no usable chapters — each needs a \"url\" or \"pages\"."
            return 0
        }
        say("    ${ChapterList.FILE_NAME}: ${declared.size} chapter(s) hosted outside the bucket")

        // Open the first archive so a dead link or a host without range support
        // is reported here rather than when someone tries to read it.
        val first = declared.firstOrNull { it.archiveUrl != null } ?: return declared.size
        val url = first.archiveUrl!!.toHttpUrlOrNull()
        if (url == null) {
            problems += "\"${first.name}\" in $key has an unreadable url: ${first.archiveUrl}"
            return declared.size
        }
        runCatching {
            val zip = RemoteZip(client, url)
            val entries = zip.entries().filter { isImageKey(it.name) }
            say("    ${first.name} -> ${url.host}: ${entries.size} page(s)")
            entries.firstOrNull()?.let { entry ->
                if (!looksLikeAnImage(zip.read(entry))) {
                    problems += "\"${entry.name}\" from ${url.host} is not a readable image."
                }
            }
        }.onFailure {
            problems += "\"${first.name}\" of \"$seriesName\" could not be opened from " +
                "${url.host}: ${it.message}"
        }
        return declared.size
    }

    private fun verifyMetadata(client: OkHttpClient, config: R2Config, obj: S3Object) {
        val key = obj.key
        if (obj.size == 0L) {
            problems += "$key is empty (0 bytes); the series will fall back to its folder name."
            return
        }
        val body = client.newCall(Request.Builder().url(config.objectUrl(key)).build())
            .execute().use { if (it.isSuccessful) it.body!!.string() else null }
        if (body == null) {
            problems += "Could not download $key."
            return
        }
        val parsed = if (key.fileName().equals(SeriesMetadata.DETAILS_JSON, true)) {
            SeriesMetadata.fromDetailsJson(body)
        } else {
            SeriesMetadata.fromComicInfo(body)
        }
        if (parsed == null) {
            problems += "$key could not be parsed; the series will fall back to its folder name."
        } else {
            say("    parsed ${key.fileName()}: title=${parsed.title}, author=${parsed.author}, status=${parsed.status}")
        }
    }

    private fun verifyPublicOrigin(client: OkHttpClient, config: R2Config, pages: FirstPages?) {
        heading("6. Public origin")
        val url = pages?.probeUrl
        if (url == null || config.publicBaseUrl == null) {
            say("Nothing to check.")
            return
        }
        if (!url.startsWith(config.publicBaseUrl.toString())) {
            problems += "Images are not being built from the public origin as expected."
            return
        }
        val request = Request.Builder().url(url).header("Range", "bytes=0-255").build()
        client.newCall(request).execute().use { response ->
            if (response.isSuccessful) {
                say("OK — the public origin serves images (HTTP ${response.code}).")
            } else {
                problems += "The public origin returned HTTP ${response.code} for a page. " +
                    "Check that public access is enabled for this bucket, or clear the setting."
            }
        }
    }

    private fun report() {
        heading("Result")
        if (notes.isNotEmpty()) {
            say("Notes:")
            notes.distinct().forEach { say("  - $it") }
        }
        if (problems.isEmpty()) {
            say("No problems found. The extension should work against this bucket.")
        } else {
            say("Problems:")
            problems.distinct().forEach { say("  ! $it") }
            throw AssertionError("${problems.distinct().size} problem(s) found — see above.")
        }
    }

    private fun env(name: String): String? = System.getenv(name)?.takeIf { it.isNotBlank() }

    private fun heading(text: String) {
        println()
        println("── $text ${"─".repeat(maxOf(0, 60 - text.length))}")
    }

    private fun say(text: String) = println(text)

    private companion object {
        const val MAX_SERIES_INSPECTED = 5

        /** Magic bytes for the formats a reader will accept. */
        fun looksLikeAnImage(bytes: ByteArray): Boolean {
            if (bytes.size < 4) return false
            fun at(index: Int) = bytes[index].toInt() and 0xFF
            return when {
                at(0) == 0xFF && at(1) == 0xD8 -> true // jpeg
                at(0) == 0x89 && at(1) == 0x50 -> true // png
                at(0) == 0x47 && at(1) == 0x49 -> true // gif
                bytes.size >= 12 && String(bytes, 8, 4, Charsets.US_ASCII) == "WEBP" -> true
                bytes.size >= 12 && String(bytes, 4, 4, Charsets.US_ASCII) == "ftyp" -> true // avif/heif
                at(0) == 0x42 && at(1) == 0x4D -> true // bmp
                else -> false
            }
        }
    }

    private fun describeRoot(config: R2Config): String =
        if (config.rootPrefix.isEmpty()) "bucket \"${config.bucket}\"" else "\"${config.rootPrefix}\""
}
