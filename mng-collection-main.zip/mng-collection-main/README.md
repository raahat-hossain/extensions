# MNG Collection

A Tachiyomi / Mihon / Tachimanga extension that reads a manga library straight
out of a **Cloudflare R2** bucket.

There is no server, no Worker and no generated index to maintain. The extension
talks to R2's S3-compatible API directly: folders are series, their subfolders
(or `.cbz` files) are chapters, and the images inside are pages. Upload files,
pull to refresh, done.

---

## Bucket layout

```
your-bucket/
└── manga/                        ← optional "library folder" (configurable)
    ├── Blame!/
    │   ├── cover.jpg             ← optional series cover
    │   ├── details.json          ← optional series metadata
    │   ├── Chapter 001/
    │   │   ├── 001.jpg
    │   │   ├── 002.jpg
    │   │   └── 003.jpg
    │   └── Chapter 002/
    │       └── ...
    └── Oyasumi Punpun/
        ├── cover.jpg
        ├── ComicInfo.xml         ← alternative to details.json
        ├── Chapter 001.cbz       ← archives work too
        └── Chapter 002.cbz
```

Both chapter styles are supported and can be mixed inside the same library.

* **Folders of loose images** — recommended. Each page is its own object, so
  pages load in parallel, resume cleanly, and cache individually (on the device
  and at Cloudflare's edge).
* **`.cbz` / `.zip` archives** — supported. The extension reads the zip's index
  with HTTP range requests and pulls out one page at a time, so it never
  downloads a whole archive to show you a page. Opening a chapter costs one
  extra round trip compared to loose images.

* **Chapters hosted elsewhere** — a `chapters.json` in the series folder can
  point chapters at an archive on any other host, read the same way:

  ```json
  { "chapters": [ { "name": "Chapter 001", "url": "https://manga.com/bsjsh.cbz" } ] }
  ```

  These are merged with whatever is stored in the bucket, so a series can be
  part local and part remote, or hold no content at all. The remote host must
  support range requests, and must not need credentials — the bucket's keys are
  never sent anywhere but the configured endpoint. See
  [`docs/UPLOADING.md`](docs/UPLOADING.md) for the full format.

Chapter folders may be nested (`Blame!/Volume 1/Chapter 003/001.jpg`); the
deepest folder holding images is the chapter, and the label becomes
`Volume 1 – Chapter 003`. If a series folder contains images directly and no
chapters, it is treated as a single chapter.

Sorting is natural, so `Chapter 2` comes before `Chapter 10`. Chapter numbers
are recognised from names like `Chapter 001`, `Ch.12`, `c007 - Title`,
`v02 c013` and `12.5`. `.DS_Store`, `Thumbs.db` and `__MACOSX/` are ignored.

### A note on `ComicInfo.xml`

It is worth being precise here, because the two files do different jobs:

* **`ComicInfo.xml` is the ComicRack per-issue format.** In the wider ecosystem
  it normally lives *inside* each `.cbz` and describes that one chapter.
* **`details.json` is Tachiyomi/Mihon's per-series format**, and it sits in the
  series folder.

This extension reads **series-level metadata only**, from a `details.json` *or*
a `ComicInfo.xml` placed in the series folder (`details.json` wins if both are
present). It deliberately does **not** open every archive to read the
`ComicInfo.xml` inside — that would mean fetching part of every `.cbz` in your
library just to draw the browse screen.

So: keep a `ComicInfo.xml` inside your archives if you like, other tools will
use it. For this extension, put one copy in the series folder.

Metadata is entirely optional. With no metadata file the folder name is the
title and everything else is left blank.

> Handing the uploading to someone else? [`docs/UPLOADING.md`](docs/UPLOADING.md)
> is a self-contained spec of the layout, naming and metadata rules.

`details.json`:

```json
{
  "title": "Blame!",
  "author": "Tsutomu Nihei",
  "artist": "Tsutomu Nihei",
  "description": "A very long walk.",
  "genre": ["Sci-Fi", "Action"],
  "status": "completed"
}
```

`genre` accepts a list or a comma-separated string. `status` accepts a name
(`ongoing`, `completed`, `licensed`, `publishing finished`, `cancelled`,
`on hiatus`) or the equivalent number.

Series-level `ComicInfo.xml` uses `Series`/`Title`, `Summary`, `Writer`,
`Penciller`, `CoverArtist`, `Genre`, `Tags` and `Status`.

### Covers

The extension looks for `cover.<ext>` in the series folder first. Failing that
it falls back to the first page of the first chapter, so covers show up even
with no preparation — adding `cover.jpg` just makes browsing faster.

---

## Setup

### 1. Create a read-only R2 API token

In the Cloudflare dashboard: **R2 → API → Manage API Tokens → Create API
Token**.

* Permission: **Object Read only**
* Scope it to the single bucket you are serving

Cloudflare then shows you an **Access Key ID**, a **Secret Access Key** (once
only), and an **S3 endpoint** of the form
`https://<account-id>.r2.cloudflarestorage.com`.

> The token is stored in the app's private preferences on your device. Keep it
> read-only and bucket-scoped so a lost phone (or an app backup that includes
> source settings) cannot be used to modify or delete anything.

### 2. Install the extension

CI publishes the APK and an `index.min.json` to the `repo` branch on every push
to `main`. There are three ways to get it onto a device.

**a. Sideload the APK.** Download it from the **Actions** tab of this repository
(build artifact) and install it. Works regardless of repository visibility.

**b. Add an extension repo — needs a *public* GitHub repository.** In
**Settings → Browse → Extension repos** (Mihon) or **Settings → Extension
repos** (Tachimanga):

```
https://raw.githubusercontent.com/Mohammad-Rahat/mng-collection/repo/index.min.json
```

> ⚠️ This repository is currently **private**, so that URL returns 404 to the
> app — `raw.githubusercontent.com` requires a token for private repositories
> and the app cannot send one. Either make the repository public, or use option
> (a) or (c).

**c. Host the repo index in R2.** Since you already have a bucket, copy
`index.min.json` and `apk/<name>.apk` from the `repo` branch into a public
prefix and point the app at that URL instead. This keeps the source private
while still getting in-app updates.

However you install it, the app will warn that the extension is untrusted the
first time. That is expected for any extension outside the official repo, and
you can accept it.

### 3. Fill in the settings

Open the source's settings and enter:

| Setting | Required | Notes |
| --- | --- | --- |
| Account ID or S3 endpoint | yes | Either the bare account id or the full endpoint URL |
| Bucket name | yes | |
| Access Key ID | yes | From the R2 API token |
| Secret Access Key | yes | From the R2 API token |
| Library folder | no | e.g. `manga` if the series are not at the bucket root |
| Public image URL | no | See below |
| Region | no | Leave as `auto` |
| Re-read the bucket every | no | Listing cache lifetime, default 5 minutes |
| Latest updates scan limit | no | See "Latest updates" below |
| Clear cached listings | no | Flip to re-read the bucket immediately |

---

## Serving images from a public URL (optional, recommended)

If you attach a **custom domain** to the bucket (or enable the `r2.dev`
development URL) and put that address in **Public image URL**, page and cover
images load straight from it instead of being signed one request at a time.

Listing still goes through the API token, so the bucket contents are only
discoverable by someone who has the token — but note that anything served from
a public origin is readable by anyone who knows the URL.

With a custom domain the images also go through Cloudflare's cache, which is
faster on repeat reads and keeps R2 Class B operation counts down.

---

## How it behaves

* **Browse / search** lists the series folders (one request, cached) and filters
  them on the device, so search is instant and matches folder names.
* **Latest updates** has to work around object storage: S3 listings come back in
  alphabetical order, never by date, so the extension scans the library and
  keeps the newest object per series. The scan is capped by *Latest updates scan
  limit* (default 10 × 1000 objects). Raise it if a large library looks
  incomplete there; browse and search are unaffected.
* **Clock skew** is corrected automatically. SigV4 rejects signatures more than
  15 minutes out of date, so if the device clock has drifted the extension
  learns the offset from R2 and retries.

## Checking a bucket before you install anything

`scripts/probe-bucket.sh` points the extension's own code — the same signing,
listing, metadata and archive readers that run on the device — at a real bucket
and reports what the source would show:

```bash
scripts/probe-bucket.sh
```

It prompts for the account id, bucket and keys (the secret is read hidden, so it
never lands in your shell history) and prints something like:

```
── 2. Series ───────────────────────────────────────────────────
3 series found. First few:
  • Blame!
  • Oyasumi Punpun (2007)

── 3. Series contents ──────────────────────────────────────────
  • Blame! — 2 chapter folder(s), 0 archive(s), cover, details.json
    parsed details.json: title=Blame!, author=Tsutomu Nihei, status=2

── 4. Open the first chapter ───────────────────────────────────
"Blame!" → Chapter 001: 2 page(s)

── Result ──────────────────────────────────────────────────────
No problems found. The extension should work against this bucket.
```

It calls out the things that actually go wrong in practice: a token without read
access, a library folder that points at nothing, series with no chapters,
archives in a format that cannot be opened, and metadata files that fail to
parse. Credentials are never printed, only what they unlock.

It can also be driven from the environment, for example in a script:

```bash
R2_ACCOUNT_ID=... R2_BUCKET=... R2_ACCESS_KEY_ID=... R2_SECRET_ACCESS_KEY=... \
  ./gradlew :extension:testReleaseUnitTest --tests '*BucketProbe*'
```

The probe is skipped during ordinary test runs, so CI is unaffected.

## Limitations

* `.cbr`, `.rar`, `.cb7` and `.pdf` cannot be opened — they are not zip archives
  (`.cbr` is RAR, which has no free decoder that can stream over HTTP). The
  extension says so explicitly rather than showing an empty series. Convert them
  to `.cbz`.
* Listing requires an API token. R2's public bucket URLs serve objects but
  cannot enumerate them, so a public-only bucket cannot be browsed.
* Encrypted archives are not supported.

---

## Building it yourself

Requires JDK 17+ and an Android SDK.

```bash
./gradlew :extension:testReleaseUnitTest   # unit tests
./gradlew :extension:assembleRelease       # APK in extension/build/outputs/apk/release/
```

### Signing

Android ties app identity to the signing key: an APK signed with a different key
will not install over an existing one. With no key configured, each build falls
back to a debug key — and because CI runners are fresh every time, that means
**every CI build gets a different key and none of them can update the last**.
You would have to uninstall first, losing the source's settings each time.

Set it up once:

```bash
scripts/make-keystore.sh
```

It creates the keystore, then either sets the four repository secrets for you
(if the GitHub CLI is installed) or prints them to paste into
**Settings → Secrets and variables → Actions**: `KEYSTORE_BASE64`,
`KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`. CI picks them up
automatically and signs every release with that key.

Keep the `.jks` file backed up and out of git — `.gitignore` already covers
`*.jks`. Losing it means installed copies can never be updated again.

Bump `extVersionCode` in `extension/build.gradle.kts` for every release you want
the app to offer as an update.

### Layout

```
extension/src/main/kotlin/.../mngcollection/
├── MngCollection.kt          the source: browse, details, chapters, pages, settings
├── net/R2Config.kt           endpoint/bucket config and AWS-style URL encoding
├── net/SigV4Interceptor.kt   request signing (+ clock-skew recovery)
├── net/S3Client.kt           ListObjectsV2 and its XML
├── net/RemoteZip.kt          reads a .cbz over HTTP range requests
├── net/ArchiveSupport.kt     serves archive pages to the reader as if they were URLs
├── meta/SeriesMetadata.kt    details.json and ComicInfo.xml
└── util/Naming.kt            natural sort, chapter numbers, file classification
```

The request signing is checked against the worked example in the AWS Signature
Version 4 documentation, and the archive reader against real zips built by
`java.util.zip`.
