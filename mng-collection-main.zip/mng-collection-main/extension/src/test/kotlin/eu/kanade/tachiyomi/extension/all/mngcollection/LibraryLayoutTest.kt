package eu.kanade.tachiyomi.extension.all.mngcollection

import eu.kanade.tachiyomi.extension.all.mngcollection.meta.SeriesMetadata
import eu.kanade.tachiyomi.extension.all.mngcollection.net.R2Config
import eu.kanade.tachiyomi.extension.all.mngcollection.util.NaturalOrder
import eu.kanade.tachiyomi.extension.all.mngcollection.util.chapterNumberOf
import eu.kanade.tachiyomi.extension.all.mngcollection.util.isArchiveKey
import eu.kanade.tachiyomi.extension.all.mngcollection.util.isHiddenKey
import eu.kanade.tachiyomi.extension.all.mngcollection.util.isImageKey
import eu.kanade.tachiyomi.extension.all.mngcollection.util.isUnsupportedArchiveKey
import eu.kanade.tachiyomi.source.model.SManga
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class NamingTest {

    @Test
    fun `sorts chapters the way a reader expects`() {
        val input = listOf("Chapter 10", "Chapter 2", "Chapter 1", "Chapter 20", "Chapter 3")
        assertEquals(
            listOf("Chapter 1", "Chapter 2", "Chapter 3", "Chapter 10", "Chapter 20"),
            input.sortedWith(NaturalOrder),
        )
    }

    @Test
    fun `treats padded numbers as equal to bare ones`() {
        assertEquals(0, NaturalOrder.compare("007.jpg", "7.jpg"))
        assertEquals(0, NaturalOrder.compare("0", "0"))
        assertTrue(NaturalOrder.compare("9.jpg", "10.jpg") < 0)
    }

    @Test
    fun `sorts page files numerically`() {
        val input = listOf("p100.webp", "p9.webp", "p10.webp", "p1.webp")
        assertEquals(
            listOf("p1.webp", "p9.webp", "p10.webp", "p100.webp"),
            input.sortedWith(NaturalOrder),
        )
    }

    @Test
    fun `recognises chapter numbers in common naming styles`() {
        assertEquals(1f, chapterNumberOf("Chapter 001"), 0f)
        assertEquals(12f, chapterNumberOf("Ch.12"), 0f)
        assertEquals(12.5f, chapterNumberOf("chapter 12.5"), 0f)
        assertEquals(7f, chapterNumberOf("c007 - The Title"), 0f)
        assertEquals(3f, chapterNumberOf("Blame! - 3.cbz"), 0f)
        assertEquals(42f, chapterNumberOf("Episode 42"), 0f)
        assertEquals(5f, chapterNumberOf("005"), 0f)
    }

    @Test
    fun `prefers the chapter number over the volume number`() {
        assertEquals(13f, chapterNumberOf("v02 c013"), 0f)
        assertEquals(4f, chapterNumberOf("Vol. 1 Chapter 4"), 0f)
    }

    @Test
    fun `ignores numbers that belong to the series title`() {
        assertEquals(3f, chapterNumberOf("Mobile Suit Gundam 0079 - Chapter 3", "Mobile Suit Gundam 0079"), 0f)
    }

    @Test
    fun `reports unknown when there is no number at all`() {
        assertEquals(-1f, chapterNumberOf("Extras"), 0f)
        assertEquals(-1f, chapterNumberOf("Omake"), 0f)
    }

    @Test
    fun `classifies file types`() {
        assertTrue(isImageKey("a/001.JPG"))
        assertTrue(isImageKey("a/001.webp"))
        assertTrue(isArchiveKey("a/Chapter 1.cbz"))
        assertTrue(isArchiveKey("a/Chapter 1.ZIP"))
        assertFalse(isArchiveKey("a/Chapter 1.cbr"))
        assertTrue(isUnsupportedArchiveKey("a/Chapter 1.cbr"))
        assertTrue(isUnsupportedArchiveKey("a/book.pdf"))

        assertTrue(isHiddenKey("a/.DS_Store"))
        assertTrue(isHiddenKey("__MACOSX/a/001.jpg"))
        assertTrue(isHiddenKey("a/Thumbs.db"))
        assertFalse(isHiddenKey("a/001.jpg"))
        // Junk must never be mistaken for a page.
        assertFalse(isImageKey("__MACOSX/a/._001.jpg"))
    }
    @Test
    fun `excludes only the upload staging folder`() {
        assertTrue(isExcludedSeriesName("upload"))
        assertTrue(isExcludedSeriesName("UPLOAD"))
        assertFalse(isExcludedSeriesName("uploads"))
        assertFalse(isExcludedSeriesName("My upload"))
    }

    @Test
    fun `uses metadata title for browse cards and falls back to folder name`() {
        assertEquals("Oyako Swap", displayTitle("oyako-swap", "Oyako Swap"))
        assertEquals("oyako-swap", displayTitle("oyako-swap", null))
        assertEquals("oyako-swap", displayTitle("oyako-swap", "   "))
        assertEquals("Oyako Swap", displayTitle("oyako-swap", "  Oyako Swap  "))
    }
}

class R2ConfigTest {

    private fun config(endpoint: String, publicBase: String? = null) = R2Config(
        endpoint = R2Config.parseEndpoint(endpoint)!!,
        bucket = "manga",
        accessKeyId = "k",
        secretAccessKey = "s",
        region = "auto",
        rootPrefix = "",
        publicBaseUrl = publicBase?.let(R2Config::parsePublicBase),
    )

    @Test
    fun `expands a bare account id into the R2 endpoint`() {
        assertEquals(
            "https://abc123.r2.cloudflarestorage.com/",
            R2Config.parseEndpoint("abc123").toString(),
        )
    }

    @Test
    fun `accepts a full endpoint, with or without a scheme`() {
        assertEquals(
            "https://abc123.eu.r2.cloudflarestorage.com/",
            R2Config.parseEndpoint("https://abc123.eu.r2.cloudflarestorage.com/").toString(),
        )
        assertEquals(
            "https://abc123.r2.cloudflarestorage.com/",
            R2Config.parseEndpoint("abc123.r2.cloudflarestorage.com").toString(),
        )
        assertNull(R2Config.parseEndpoint("   "))
    }

    @Test
    fun `normalises the library folder`() {
        assertEquals("", R2Config.normalizePrefix(""))
        assertEquals("manga/", R2Config.normalizePrefix("manga"))
        assertEquals("manga/", R2Config.normalizePrefix("/manga/"))
        assertEquals("a/b/", R2Config.normalizePrefix(" a/b "))
    }

    @Test
    fun `builds signed object urls with AWS-style encoding`() {
        val url = config("acct").objectUrl("Oyasumi Punpun (2007)/Ch 1/001.jpg")
        assertEquals(
            "https://acct.r2.cloudflarestorage.com/manga/Oyasumi%20Punpun%20%282007%29/Ch%201/001.jpg",
            url.toString(),
        )
    }

    @Test
    fun `prefers the public origin for images when one is set`() {
        val withPublic = config("acct", "https://pub-abc.r2.dev")
        assertEquals(
            "https://pub-abc.r2.dev/Blame%21/001.jpg",
            withPublic.imageUrl("Blame!/001.jpg").toString(),
        )

        val withoutPublic = config("acct")
        assertEquals(
            "https://acct.r2.cloudflarestorage.com/manga/Blame%21/001.jpg",
            withoutPublic.imageUrl("Blame!/001.jpg").toString(),
        )
    }

    @Test
    fun `encodes non-ascii keys as utf-8`() {
        val url = config("acct").objectUrl("よつばと！/001.jpg")
        assertTrue(url.toString(), url.encodedPath.startsWith("/manga/%E3%82%88%E3%81%A4%E3%81%B0%E3%81%A8"))
    }
}

class SeriesMetadataTest {

    @Test
    fun `reads details json with a genre list`() {
        val metadata = SeriesMetadata.fromDetailsJson(
            """
            {
              "title": "Blame!",
              "author": "Tsutomu Nihei",
              "description": "A very long walk.",
              "genre": ["Sci-Fi", "Action"],
              "status": "2"
            }
            """.trimIndent(),
        )!!

        assertEquals("Blame!", metadata.title)
        assertEquals("Tsutomu Nihei", metadata.author)
        assertEquals("Sci-Fi, Action", metadata.genre)
        assertEquals(SManga.COMPLETED, metadata.status)
    }

    @Test
    fun `accepts genre as a plain string and status by name`() {
        val metadata = SeriesMetadata.fromDetailsJson(
            """{"title":"X","genre":"Action, Comedy","status":"ongoing"}""",
        )!!

        assertEquals("Action, Comedy", metadata.genre)
        assertEquals(SManga.ONGOING, metadata.status)
    }

    @Test
    fun `accepts an unquoted status number and ignores unknown fields`() {
        val metadata = SeriesMetadata.fromDetailsJson(
            """
            {
              "title": "X",
              "status": 2,
              "genre": ["Action"],
              "notes": { "anything": ["extra", "fields"] }
            }
            """.trimIndent(),
        )!!

        assertEquals(SManga.COMPLETED, metadata.status)
        assertEquals("Action", metadata.genre)
        assertEquals("X", metadata.title)
    }

    @Test
    fun `treats missing and null fields as absent`() {
        val metadata = SeriesMetadata.fromDetailsJson(
            """{"title":"X","author":null,"description":""}""",
        )!!

        assertNull(metadata.author)
        assertNull(metadata.description)
        assertEquals(SManga.UNKNOWN, metadata.status)
    }

    @Test
    fun `does not throw on a malformed file`() {
        assertNull(SeriesMetadata.fromDetailsJson("{ not json"))
    }

    @Test
    fun `reads ComicInfo xml`() {
        val metadata = SeriesMetadata.fromComicInfo(
            """
            <?xml version="1.0"?>
            <ComicInfo>
              <Series>Oyasumi Punpun</Series>
              <Summary>Growing up.</Summary>
              <Writer>Inio Asano</Writer>
              <Genre>Drama</Genre>
              <Tags>Slice of Life</Tags>
              <PublishingStatusTachiyomi>Completed</PublishingStatusTachiyomi>
            </ComicInfo>
            """.trimIndent(),
        )!!

        assertEquals("Oyasumi Punpun", metadata.title)
        assertEquals("Inio Asano", metadata.author)
        assertEquals("Growing up.", metadata.description)
        assertEquals("Drama, Slice of Life", metadata.genre)
        assertEquals(SManga.COMPLETED, metadata.status)
    }

    @Test
    fun `maps every documented status name`() {
        assertEquals(SManga.UNKNOWN, SeriesMetadata.statusOf(null))
        assertEquals(SManga.ONGOING, SeriesMetadata.statusOf("Ongoing"))
        assertEquals(SManga.COMPLETED, SeriesMetadata.statusOf("completed"))
        assertEquals(SManga.LICENSED, SeriesMetadata.statusOf("3"))
        assertEquals(SManga.PUBLISHING_FINISHED, SeriesMetadata.statusOf("publishing_finished"))
        assertEquals(SManga.CANCELLED, SeriesMetadata.statusOf("Cancelled"))
        assertEquals(SManga.ON_HIATUS, SeriesMetadata.statusOf("on hiatus"))
        assertEquals(SManga.UNKNOWN, SeriesMetadata.statusOf("something else"))
    }
}
