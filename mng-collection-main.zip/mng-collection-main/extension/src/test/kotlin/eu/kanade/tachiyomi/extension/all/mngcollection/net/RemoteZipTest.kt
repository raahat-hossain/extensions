package eu.kanade.tachiyomi.extension.all.mngcollection.net

import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Exercises the range-request zip reader against real archives built by
 * java.util.zip, served by a client that honours `Range` the way R2 does.
 */
class RemoteZipTest {

    private val url = "https://bucket.example/One%20Piece/Chapter%20001.cbz".toHttpUrl()

    /** Stands in for object storage: serves byte ranges out of a buffer. */
    private fun clientServing(content: ByteArray): OkHttpClient = OkHttpClient.Builder()
        .addInterceptor { chain ->
            val request = chain.request()
            val range = request.header("Range")
                ?: error("RemoteZip must always send a Range header")
            val spec = range.removePrefix("bytes=")

            val (start, endInclusive) = if (spec.startsWith("-")) {
                val suffix = spec.drop(1).toInt()
                maxOf(0, content.size - suffix) to content.size - 1
            } else {
                val from = spec.substringBefore('-').toLong()
                val to = spec.substringAfter('-').toLongOrNull() ?: (content.size - 1).toLong()
                from.toInt() to minOf(to, (content.size - 1).toLong()).toInt()
            }

            val slice = content.copyOfRange(start, endInclusive + 1)
            Response.Builder()
                .request(request)
                .protocol(Protocol.HTTP_1_1)
                .code(206)
                .message("Partial Content")
                .header("Content-Range", "bytes $start-$endInclusive/${content.size}")
                .body(slice.toResponseBody("application/octet-stream".toMediaType()))
                .build()
        }
        .build()

    private fun zipOf(vararg entries: Triple<String, ByteArray, Int>): ByteArray {
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { zip ->
            entries.forEach { (name, bytes, method) ->
                val entry = ZipEntry(name).apply {
                    this.method = method
                    if (method == ZipEntry.STORED) {
                        size = bytes.size.toLong()
                        compressedSize = bytes.size.toLong()
                        crc = java.util.zip.CRC32().apply { update(bytes) }.value
                    }
                }
                zip.putNextEntry(entry)
                zip.write(bytes)
                zip.closeEntry()
            }
        }
        return out.toByteArray()
    }

    /** Compressible content, so deflate actually does something. */
    private fun pageBytes(seed: Int, size: Int = 40_000): ByteArray =
        ByteArray(size) { ((it * 31 + seed) % 7).toByte() }

    @Test
    fun `lists deflated entries and reads them back byte for byte`() {
        val first = pageBytes(1)
        val second = pageBytes(2)
        val content = zipOf(
            Triple("001.jpg", first, ZipEntry.DEFLATED),
            Triple("002.jpg", second, ZipEntry.DEFLATED),
        )
        val zip = RemoteZip(clientServing(content), url)

        val entries = zip.entries()
        assertEquals(listOf("001.jpg", "002.jpg"), entries.map { it.name })
        assertTrue("deflate should have shrunk the payload", entries[0].compressedSize < first.size)

        assertArrayEquals(first, zip.read(entries[0]))
        assertArrayEquals(second, zip.read(entries[1]))
    }

    @Test
    fun `reads stored - uncompressed - entries`() {
        val bytes = pageBytes(3, size = 5_000)
        val content = zipOf(Triple("page.png", bytes, ZipEntry.STORED))
        val zip = RemoteZip(clientServing(content), url)

        val entry = zip.entries().single()
        assertEquals(0, entry.method)
        assertArrayEquals(bytes, zip.read(entry))
    }

    @Test
    fun `skips directory entries and keeps nested paths`() {
        val bytes = pageBytes(4, size = 1_000)
        val content = zipOf(
            Triple("Chapter 001/", ByteArray(0), ZipEntry.STORED),
            Triple("Chapter 001/002.jpg", bytes, ZipEntry.DEFLATED),
        )
        val zip = RemoteZip(clientServing(content), url)

        val entries = zip.entries()
        assertEquals(listOf("Chapter 001/002.jpg"), entries.map { it.name })
        assertArrayEquals(bytes, zip.read(entries.single()))
    }

    @Test
    fun `handles archives larger than the tail window`() {
        // Forces the central directory to be fetched separately rather than
        // being found inside the trailing read.
        val entries = (1..40).map {
            Triple("%03d.jpg".format(it), pageBytes(it, size = 20_000), ZipEntry.STORED)
        }
        val content = zipOf(*entries.toTypedArray())
        assertTrue("archive should exceed the 128 KiB tail", content.size > 128 * 1024)

        val zip = RemoteZip(clientServing(content), url)
        val read = zip.entries()

        assertEquals(40, read.size)
        assertArrayEquals(entries[0].second, zip.read(read.first()))
        assertArrayEquals(entries[39].second, zip.read(read.last()))
    }

    @Test
    fun `is not fooled by an end-of-directory signature inside the comment`() {
        val bytes = pageBytes(6, size = 2_000)
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { zip ->
            // "PK\u0005\u0006" is the end-of-central-directory signature. A
            // backwards scan that does not validate the record would latch onto
            // this copy instead of the real one.
            zip.setComment("PK\u0005\u0006" + "x".repeat(80))
            zip.putNextEntry(ZipEntry("001.jpg"))
            zip.write(bytes)
            zip.closeEntry()
        }
        val zip = RemoteZip(clientServing(out.toByteArray()), url)

        assertEquals(listOf("001.jpg"), zip.entries().map { it.name })
        assertArrayEquals(bytes, zip.read(zip.entries().single()))
    }

    /** Serves the whole file for every request, ignoring `Range` entirely. */
    private fun clientIgnoringRanges(content: ByteArray, requests: MutableList<String>) =
        OkHttpClient.Builder()
            .addInterceptor { chain ->
                requests += chain.request().header("Range").orEmpty()
                Response.Builder()
                    .request(chain.request())
                    .protocol(Protocol.HTTP_1_1)
                    .code(200)
                    .message("OK")
                    .body(content.toResponseBody("application/octet-stream".toMediaType()))
                    .build()
            }
            .build()

    @Test
    fun `copes with a host that ignores range requests`() {
        val first = pageBytes(7, size = 3_000)
        val second = pageBytes(8, size = 3_000)
        val content = zipOf(
            Triple("001.jpg", first, ZipEntry.DEFLATED),
            Triple("002.jpg", second, ZipEntry.DEFLATED),
        )
        val requests = mutableListOf<String>()
        val zip = RemoteZip(clientIgnoringRanges(content, requests), url)

        val entries = zip.entries()
        assertArrayEquals(first, zip.read(entries[0]))
        assertArrayEquals(second, zip.read(entries[1]))

        // The archive arrived whole on the first request, so reading pages must
        // not fetch it again.
        assertEquals("only the initial request should hit the network", 1, requests.size)
    }

    @Test
    fun `refuses an oversized archive from a host that ignores ranges`() {
        // Larger than the in-memory limit, so every page would re-download it.
        val huge = ByteArray(25 * 1024 * 1024)
        val requests = mutableListOf<String>()
        val zip = RemoteZip(clientIgnoringRanges(huge, requests), url)

        val failure = runCatching { zip.entries() }.exceptionOrNull()
        assertTrue(failure is java.io.IOException)
        assertTrue(
            failure!!.message.orEmpty(),
            failure.message.orEmpty().contains("does not support range requests") ||
                failure.message.orEmpty().contains("ignores range requests"),
        )
    }

    @Test
    fun `survives a zip comment after the directory`() {
        val bytes = pageBytes(5, size = 2_000)
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { zip ->
            zip.setComment("packed by a tool that likes comments")
            zip.putNextEntry(ZipEntry("001.webp"))
            zip.write(bytes)
            zip.closeEntry()
        }
        val zip = RemoteZip(clientServing(out.toByteArray()), url)

        assertArrayEquals(bytes, zip.read(zip.entries().single()))
    }
}
