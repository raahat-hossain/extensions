#!/usr/bin/env bash
#
# Creates the signing key CI uses for release builds, and prints the four
# repository secrets to set.
#
# Android ties app identity to the signing key: an APK signed with a different
# key will not install over an existing one. Without a fixed key here, every CI
# run produces a fresh throwaway key, so no build can ever update the last.
#
# Run this once. Keep the .jks file safe and never commit it — losing it means
# no future build can update an installed copy.

set -euo pipefail
cd "$(dirname "$0")/.."

KEYSTORE=${1:-mng-release.jks}
ALIAS=${KEY_ALIAS:-mng}

if ! command -v keytool >/dev/null 2>&1; then
  echo "keytool not found — install a JDK (it ships with one)." >&2
  exit 1
fi

if [ -e "$KEYSTORE" ]; then
  echo "$KEYSTORE already exists. Delete it first, or pass another filename." >&2
  echo "Careful: replacing a key already used for a published build breaks updates." >&2
  exit 1
fi

echo "Creating $KEYSTORE (alias: $ALIAS)"
echo

read -r -s -p "Choose a password for the keystore: " PASSWORD
echo
read -r -s -p "Repeat it: " CONFIRM
echo
[ "$PASSWORD" = "$CONFIRM" ] || { echo "Passwords do not match." >&2; exit 1; }
[ ${#PASSWORD} -ge 6 ] || { echo "keytool requires at least 6 characters." >&2; exit 1; }

keytool -genkeypair \
  -keystore "$KEYSTORE" \
  -alias "$ALIAS" \
  -keyalg RSA \
  -keysize 4096 \
  -validity 10000 \
  -storepass "$PASSWORD" \
  -keypass "$PASSWORD" \
  -dname "CN=MNG Collection, O=MNG Collection, C=US" \
  >/dev/null 2>&1

# BSD base64 (macOS) has no -w flag; GNU wraps at 76 columns without it.
if base64 --help 2>&1 | grep -q -- '-w'; then
  ENCODED=$(base64 -w0 "$KEYSTORE")
else
  ENCODED=$(base64 "$KEYSTORE" | tr -d '\n')
fi

echo
echo "Created $KEYSTORE"
echo

if command -v gh >/dev/null 2>&1; then
  echo "The GitHub CLI is available. Set the secrets now? [y/N]"
  read -r reply
  if [ "$reply" = "y" ] || [ "$reply" = "Y" ]; then
    printf '%s' "$ENCODED"  | gh secret set KEYSTORE_BASE64
    printf '%s' "$PASSWORD" | gh secret set KEYSTORE_PASSWORD
    printf '%s' "$ALIAS"    | gh secret set KEY_ALIAS
    printf '%s' "$PASSWORD" | gh secret set KEY_PASSWORD
    echo
    echo "Done. Push a commit and CI will sign with this key."
    echo "Back up $KEYSTORE somewhere safe, then keep it out of git."
    exit 0
  fi
fi

cat <<EOF
Add these four repository secrets, under
  Settings -> Secrets and variables -> Actions -> New repository secret

  KEYSTORE_PASSWORD   the password you just chose
  KEY_ALIAS           $ALIAS
  KEY_PASSWORD        the same password
  KEYSTORE_BASE64     the long line printed below

--- KEYSTORE_BASE64 (copy the whole line) ---
$ENCODED
--- end ---

After that, every CI build is signed with this key and can update the last one.

Back up $KEYSTORE somewhere safe. It is already covered by .gitignore (*.jks);
do not commit it. If you lose it, installed copies can never be updated again —
they have to be uninstalled and reinstalled, losing the source's settings.
EOF
