package eu.kanade.tachiyomi.extension.all.mngcollection.meta

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ChapterListTest {

    @Test
    fun `reads chapters pointing at archives elsewhere`() {
        val chapters = ChapterList.parse(
            """
            {
              "chapters": [
                { "name": "Chapter 001", "url": "https://manga.com/bsjsh.cbz" },
                { "name": "Chapter 002", "url": "https://manga.com/other.zip",
                  "date": "2026-02-03", "scanlator": "Some Group", "number": 2 }
              ]
            }
            """.trimIndent(),
        )

        assertEquals(2, chapters.size)
        assertEquals("Chapter 001", chapters[0].name)
        assertEquals("https://manga.com/bsjsh.cbz", chapters[0].archiveUrl)
        assertEquals(0L, chapters[0].dateUpload)

        assertEquals("Some Group", chapters[1].scanlator)
        assertEquals(2f, chapters[1].number!!, 0f)
        assertTrue("date should parse", chapters[1].dateUpload > 0L)
    }

    @Test
    fun `accepts a bare array as well as a chapters object`() {
        val chapters = ChapterList.parse("""[{"name":"One","url":"https://h/a.cbz"}]""")
        assertEquals(listOf("One"), chapters.map { it.name })
    }

    @Test
    fun `reads chapters listing page urls directly`() {
        val chapters = ChapterList.parse(
            """
            [{ "name": "Chapter 003",
               "pages": ["https://h/1.jpg", "https://h/2.jpg", "https://h/3.jpg"] }]
            """.trimIndent(),
        )

        val chapter = chapters.single()
        assertNull(chapter.archiveUrl)
        assertEquals(3, chapter.pages.size)
        assertEquals("https://h/2.jpg", chapter.pages[1])
    }

    @Test
    fun `falls back to the archive filename when unnamed`() {
        val chapters = ChapterList.parse("""[{"url":"https://manga.com/bsjsh.cbz?token=x"}]""")
        assertEquals("bsjsh", chapters.single().name)
    }

    @Test
    fun `drops entries with nothing to read and keeps the rest`() {
        val chapters = ChapterList.parse(
            """
            [
              { "name": "Broken" },
              { "name": "Fine", "url": "https://h/a.cbz" }
            ]
            """.trimIndent(),
        )
        assertEquals(listOf("Fine"), chapters.map { it.name })
    }

    @Test
    fun `accepts several date formats`() {
        fun dateOf(value: String) = ChapterList.parse(
            """[{"name":"c","url":"https://h/a.cbz","date":$value}]""",
        ).single().dateUpload

        val expected = 1770076800000L // 2026-02-03T00:00:00Z
        assertEquals(expected, dateOf(""""2026-02-03""""))
        assertEquals(expected, dateOf(""""2026-02-03T00:00:00Z""""))
        assertEquals(expected, dateOf(""""2026-02-03T00:00:00.000Z""""))
        assertEquals(expected, dateOf("1770076800000"))
        // Seconds are widened to milliseconds.
        assertEquals(expected, dateOf("1770076800"))
    }

    @Test
    fun `never throws on a malformed file`() {
        assertEquals(emptyList<RemoteChapter>(), ChapterList.parse("{ not json"))
        assertEquals(emptyList<RemoteChapter>(), ChapterList.parse("[]"))
        assertEquals(emptyList<RemoteChapter>(), ChapterList.parse("""{"chapters":"nope"}"""))
    }
}
