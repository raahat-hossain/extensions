package eu.kanade.tachiyomi.extension.all.mngcollection.meta

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/**
 * A chapter that lives somewhere other than the bucket, declared in a
 * `chapters.json` beside the series. Either an archive URL or an explicit list
 * of page URLs; the archive is read with range requests exactly like one stored
 * in R2.
 */
data class RemoteChapter(
    val name: String,
    val archiveUrl: String?,
    val pages: List<String>,
    val number: Float?,
    val dateUpload: Long,
    val scanlator: String?,
)

/**
 * Parses `chapters.json`. Hand-written like the metadata files, so a bad entry
 * is dropped rather than failing the whole series.
 */
object ChapterList {

    const val FILE_NAME = "chapters.json"

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    fun parse(raw: String): List<RemoteChapter> = runCatching {
        val root = json.parseToJsonElement(raw)
        val array = when (root) {
            is JsonArray -> root
            is JsonObject -> root["chapters"] as? JsonArray ?: return emptyList()
            else -> return emptyList()
        }
        array.mapNotNull { element -> (element as? JsonObject)?.let(::chapterOf) }
    }.getOrDefault(emptyList())

    private fun chapterOf(entry: JsonObject): RemoteChapter? {
        val archiveUrl = entry.string("url") ?: entry.string("archive")
        val pages = entry.stringList("pages")
        if (archiveUrl == null && pages.isEmpty()) return null

        // Without a name there is nothing to show in the chapter list, so fall
        // back to the archive's filename.
        val name = entry.string("name")
            ?: entry.string("title")
            ?: archiveUrl?.substringAfterLast('/')?.substringBefore('?')?.substringBeforeLast('.')
            ?: return null

        return RemoteChapter(
            name = name,
            archiveUrl = archiveUrl,
            pages = pages,
            number = entry.string("number")?.toFloatOrNull(),
            dateUpload = parseDate(entry.string("date") ?: entry.string("date_upload")),
            scanlator = entry.string("scanlator"),
        )
    }

    private fun JsonObject.string(key: String): String? =
        (this[key] as? JsonPrimitive)?.content?.trim()
            ?.takeIf { it.isNotEmpty() && it != "null" }

    private fun JsonObject.stringList(key: String): List<String> =
        (this[key] as? JsonArray)
            ?.mapNotNull { (it as? JsonPrimitive)?.content?.trim()?.takeIf(String::isNotEmpty) }
            ?: emptyList()

    /** Accepts epoch milliseconds, `YYYY-MM-DD`, or a full ISO-8601 timestamp. */
    private fun parseDate(value: String?): Long {
        if (value.isNullOrEmpty()) return 0L
        value.toLongOrNull()?.let { return if (it < 100_000_000_000L) it * 1000 else it }
        val format = when {
            value.contains('T') && value.contains('.') -> isoWithMillis
            value.contains('T') -> iso
            else -> dateOnly
        }
        return runCatching { format.get()!!.parse(value)?.time ?: 0L }.getOrDefault(0L)
    }

    private fun utcFormat(pattern: String) = object : ThreadLocal<SimpleDateFormat>() {
        override fun initialValue() = SimpleDateFormat(pattern, Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
    }

    private val dateOnly = utcFormat("yyyy-MM-dd")
    private val iso = utcFormat("yyyy-MM-dd'T'HH:mm:ss'Z'")
    private val isoWithMillis = utcFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
}
