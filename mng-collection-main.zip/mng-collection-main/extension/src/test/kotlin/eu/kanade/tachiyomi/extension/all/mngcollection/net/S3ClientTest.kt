package eu.kanade.tachiyomi.extension.all.mngcollection.net

import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.IOException

class S3ClientTest {

    private val config = R2Config(
        endpoint = "https://acct.r2.cloudflarestorage.com".toHttpUrl(),
        bucket = "manga",
        accessKeyId = "key",
        secretAccessKey = "secret",
        region = "auto",
        rootPrefix = "library/",
        publicBaseUrl = null,
    )

    private val requested = mutableListOf<HttpUrl>()

    private fun clientReturning(vararg bodies: String, code: Int = 200): OkHttpClient =
        OkHttpClient.Builder()
            .addInterceptor { chain ->
                val request = chain.request()
                requested += request.url
                val body = bodies[minOf(requested.size - 1, bodies.size - 1)]
                Response.Builder()
                    .request(request)
                    .protocol(Protocol.HTTP_1_1)
                    .code(code)
                    .message(if (code == 200) "OK" else "Error")
                    .body(body.toResponseBody("application/xml".toMediaType()))
                    .build()
            }
            .build()

    @Test
    fun `parses folders, keys, sizes and dates`() {
        val xml = """
            <?xml version="1.0" encoding="UTF-8"?>
            <ListBucketResult>
              <Name>manga</Name>
              <Prefix>library/</Prefix>
              <IsTruncated>false</IsTruncated>
              <Contents>
                <Key>library/Blame!/cover.jpg</Key>
                <LastModified>2026-03-04T10:11:12.000Z</LastModified>
                <Size>120345</Size>
              </Contents>
              <Contents>
                <Key>library/Blame!/details.json</Key>
                <LastModified>2026-03-04T10:11:13Z</LastModified>
                <Size>210</Size>
              </Contents>
              <CommonPrefixes><Prefix>library/Blame!/</Prefix></CommonPrefixes>
              <CommonPrefixes><Prefix>library/Oyasumi Punpun/</Prefix></CommonPrefixes>
            </ListBucketResult>
        """.trimIndent()

        val listing = S3Client(clientReturning(xml)).list(config, "library/", "/")

        assertEquals(
            listOf("library/Blame!/", "library/Oyasumi Punpun/"),
            listing.prefixes,
        )
        assertEquals("library/Blame!/cover.jpg", listing.objects[0].key)
        assertEquals(120345L, listing.objects[0].size)
        assertTrue("date should parse", listing.objects[0].lastModified > 0L)
        // Timestamps with and without milliseconds are both valid.
        assertTrue("date should parse", listing.objects[1].lastModified > 0L)
        assertNull(listing.nextToken)
    }

    @Test
    fun `preserves double spaces in keys`() {
        // Jsoup's text() collapses whitespace; a key must survive verbatim or
        // every request built from it would 404.
        val xml = """
            <ListBucketResult>
              <IsTruncated>false</IsTruncated>
              <Contents><Key>library/Kino  no Tabi/001.jpg</Key><Size>1</Size></Contents>
            </ListBucketResult>
        """.trimIndent()

        val listing = S3Client(clientReturning(xml)).list(config, "library/", null)

        assertEquals("library/Kino  no Tabi/001.jpg", listing.objects.single().key)
    }

    @Test
    fun `decodes xml entities in keys`() {
        val xml = """
            <ListBucketResult>
              <IsTruncated>false</IsTruncated>
              <Contents><Key>library/Tom &amp; Jerry/001.jpg</Key><Size>1</Size></Contents>
            </ListBucketResult>
        """.trimIndent()

        val listing = S3Client(clientReturning(xml)).list(config, "library/", null)

        assertEquals("library/Tom & Jerry/001.jpg", listing.objects.single().key)
    }

    @Test
    fun `sends the expected list-objects query`() {
        val xml = "<ListBucketResult><IsTruncated>false</IsTruncated></ListBucketResult>"
        S3Client(clientReturning(xml)).list(config, "library/Oyasumi Punpun/", "/")

        val url = requested.single()
        assertEquals("/manga", url.encodedPath)
        assertEquals("2", url.queryParameter("list-type"))
        assertEquals("library/Oyasumi Punpun/", url.queryParameter("prefix"))
        assertEquals("/", url.queryParameter("delimiter"))
        // Slashes and spaces must be percent-encoded in the query, or the
        // canonical request will not match the signature.
        assertTrue(
            "prefix should be fully encoded, was ${url.encodedQuery}",
            url.encodedQuery!!.contains("prefix=library%2FOyasumi%20Punpun%2F"),
        )
    }

    @Test
    fun `follows continuation tokens`() {
        val first = """
            <ListBucketResult>
              <IsTruncated>true</IsTruncated>
              <NextContinuationToken>tok/en+1</NextContinuationToken>
              <Contents><Key>library/A/001.jpg</Key><Size>1</Size></Contents>
            </ListBucketResult>
        """.trimIndent()
        val second = """
            <ListBucketResult>
              <IsTruncated>false</IsTruncated>
              <Contents><Key>library/A/002.jpg</Key><Size>1</Size></Contents>
            </ListBucketResult>
        """.trimIndent()

        val listing = S3Client(clientReturning(first, second)).listAll(config, "library/", null)

        assertEquals(
            listOf("library/A/001.jpg", "library/A/002.jpg"),
            listing.objects.map { it.key },
        )
        assertEquals(2, requested.size)
        assertEquals("tok/en+1", requested[1].queryParameter("continuation-token"))
        assertNull(listing.nextToken)
    }

    @Test
    fun `stops at the page cap and reports more is available`() {
        val truncated = """
            <ListBucketResult>
              <IsTruncated>true</IsTruncated>
              <NextContinuationToken>more</NextContinuationToken>
              <Contents><Key>library/A/001.jpg</Key><Size>1</Size></Contents>
            </ListBucketResult>
        """.trimIndent()

        val listing = S3Client(clientReturning(truncated)).listAll(config, "library/", null, maxPages = 3)

        assertEquals(3, requested.size)
        assertTrue(listing.truncated)
    }

    @Test
    fun `surfaces a readable message for a rejected request`() {
        val error = """
            <Error><Code>InvalidAccessKeyId</Code>
            <Message>The access key id you provided does not exist.</Message></Error>
        """.trimIndent()

        val failure = runCatching {
            S3Client(clientReturning(error, code = 403)).list(config, "", null)
        }.exceptionOrNull()

        assertTrue(failure is IOException)
        val message = failure!!.message.orEmpty()
        assertTrue(message, message.contains("HTTP 403"))
        assertTrue(message, message.contains("InvalidAccessKeyId"))
        assertTrue(message, message.contains("access key id"))
    }
}
