package eu.kanade.tachiyomi.extension.all.mngcollection.net

import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.Request
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Checked against the worked examples in the AWS "Signature Version 4" docs.
 * A wrong signature here means every request to R2 comes back 403, so these
 * vectors are the safety net for the whole source.
 */
class SigV4InterceptorTest {

    private val awsExampleConfig = R2Config(
        endpoint = "https://examplebucket.s3.amazonaws.com".toHttpUrl(),
        bucket = "examplebucket",
        accessKeyId = "AKIAIOSFODNN7EXAMPLE",
        secretAccessKey = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY",
        region = "us-east-1",
        rootPrefix = "",
        publicBaseUrl = null,
    )

    /** 2013-05-24T00:00:00Z, the timestamp used by every AWS example. */
    private val exampleInstant = 1369353600000L

    private fun authorizationFor(url: String, config: R2Config = awsExampleConfig): String {
        val interceptor = SigV4Interceptor { config }
        val signed = interceptor.sign(Request.Builder().url(url).build(), config, exampleInstant)
        return signed.header("Authorization")!!
    }

    @Test
    fun `matches the AWS list-objects example signature`() {
        // AWS docs, "GET Bucket (List Objects)" example.
        val authorization = authorizationFor("https://examplebucket.s3.amazonaws.com/?max-keys=2&prefix=J")

        assertEquals(
            "AWS4-HMAC-SHA256 " +
                "Credential=AKIAIOSFODNN7EXAMPLE/20130524/us-east-1/s3/aws4_request, " +
                "SignedHeaders=host;x-amz-content-sha256;x-amz-date, " +
                "Signature=34b48302e7b5fa45bde8084f4b7868a86f0a534bc59db6670ed5711ef69dc6f7",
            authorization,
        )
    }

    @Test
    fun `sets the payload hash and date headers`() {
        val interceptor = SigV4Interceptor { awsExampleConfig }
        val signed = interceptor.sign(
            Request.Builder().url("https://examplebucket.s3.amazonaws.com/").build(),
            awsExampleConfig,
            exampleInstant,
        )

        assertEquals(
            "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
            signed.header("x-amz-content-sha256"),
        )
        assertEquals("20130524T000000Z", signed.header("x-amz-date"))
    }

    @Test
    fun `orders query parameters by name then value`() {
        // prefix sorts after max-keys, and the signature above already proves
        // the ordering; here we simply assert the two orderings agree.
        val ordered = authorizationFor("https://examplebucket.s3.amazonaws.com/?max-keys=2&prefix=J")
        val reversed = authorizationFor("https://examplebucket.s3.amazonaws.com/?prefix=J&max-keys=2")

        assertEquals(ordered, reversed)
    }

    @Test
    fun `signs keys containing spaces and parentheses`() {
        val config = awsExampleConfig
        val url = config.objectUrl("Oyasumi Punpun (2007)/Chapter 001/001.jpg")

        // OkHttp must not re-encode what awsUriEncode produced, otherwise the
        // canonical request would disagree with the wire format.
        assertEquals(
            "/examplebucket/Oyasumi%20Punpun%20%282007%29/Chapter%20001/001.jpg",
            url.encodedPath,
        )

        // Cross-checked against an independent SigV4 implementation that
        // reproduces the AWS vector above.
        val authorization = authorizationFor(url.toString(), config)
        assertTrue(authorization, authorization.endsWith(
            "Signature=a67bdcbd009d9b776bf4d519c0af9ebc63eb5cfbe614f5e41d62cd5727dae87e",
        ))
    }
}
