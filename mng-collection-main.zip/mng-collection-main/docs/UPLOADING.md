# Uploading manga to R2

Instructions for populating the bucket that the **MNG Collection** extension
reads. Written to be handed to someone (or something) doing the uploading.

## What you are doing

Uploading manga into a Cloudflare R2 bucket in a specific layout. The extension
lists the bucket directly over the S3 API — there is no database, no index file
and no import step. **The folder layout is the schema.** Get it right and the
content appears in the app; get it wrong and nothing does.

You need, from the bucket owner: the account id, the bucket name, an S3 access
key id and secret, and whether the library sits at the bucket root or inside a
folder (the "library folder").

## Required layout

```
<library folder>/                 ← omit this level if the library is at the bucket root
├── Blame!/                       ← one folder per series; the folder name is the title
│   ├── cover.jpg                 ← optional
│   ├── details.json              ← optional
│   ├── Chapter 001/              ← one folder per chapter
│   │   ├── 001.jpg               ← one file per page
│   │   ├── 002.jpg
│   │   └── 003.jpg
│   └── Chapter 002/
│       └── ...
└── Oyasumi Punpun/
    ├── cover.jpg
    ├── Chapter 001.cbz           ← archives work as an alternative to folders
    └── Chapter 002.cbz
```

Two things follow from this and are easy to get wrong:

- **Series folders must be top-level** (directly under the bucket root, or
  directly under the library folder). A file sitting loose at that level is
  ignored, and a series nested one level too deep will not be found.
- **Never upload the whole library as one archive.** One archive per *chapter*,
  never per series.

### Both chapter styles are allowed

- **Folder of loose images** — preferred. Each page is its own object, so pages
  load in parallel, resume cleanly, and cache individually.
- **`.cbz` or `.zip`** — supported. The extension reads the archive's index with
  HTTP range requests and pulls out one page at a time.

They can be mixed freely, including inside a single series.

### Optional variations that work

- **Volume nesting**: `Blame!/Volume 1/Chapter 003/001.jpg` — the deepest folder
  holding images is the chapter, labelled `Volume 1 – Chapter 003`.
- **One-shot**: images placed directly in the series folder become a single
  chapter.

## Chapters hosted somewhere else

A chapter does not have to live in the bucket. Put a `chapters.json` in the
series folder and point each chapter at an archive anywhere on the web:

```json
{
  "chapters": [
    { "name": "Chapter 001", "url": "https://manga.com/bsjsh.cbz" },
    { "name": "Chapter 002", "url": "https://cdn.example.com/ch2.zip",
      "date": "2026-02-03", "scanlator": "Some Group", "number": 2 },
    { "name": "Chapter 003",
      "pages": ["https://cdn.example.com/3/001.jpg",
                "https://cdn.example.com/3/002.jpg"] }
  ]
}
```

Each entry needs **either** `url` (an archive) **or** `pages` (image addresses
in reading order). `name`, `number`, `date` and `scanlator` are optional —
`number` is otherwise read from the name, and `date` accepts `YYYY-MM-DD`, a
full ISO-8601 timestamp, or a Unix time.

A top-level array works too, if you prefer: `[ { ... }, { ... } ]`.

These chapters are **merged with** whatever folders and archives are already in
the series, so a series can be part local and part remote. A series can equally
hold nothing but `details.json` and `chapters.json`, with every byte of content
elsewhere.

### Requirements for the remote host

- **It must support HTTP range requests** (`Accept-Ranges: bytes`). This is how
  a single page is pulled out without downloading the whole archive. Static
  hosts and CDNs almost always do; some dynamic download endpoints and consumer
  file-sharing links do not. If a host ignores ranges, a small archive still
  works (it is held in memory) but anything over 24 MB is refused with an
  explanatory error rather than re-downloaded for every page.
- **It must be reachable without credentials.** Bucket credentials are only ever
  sent to the configured R2 endpoint, never to another host, so a URL needing
  authentication will fail. Signed/expiring URLs work until they expire.
- Redirects are followed normally.

Check a candidate host with:

```bash
curl -sI -H 'Range: bytes=0-99' 'https://manga.com/bsjsh.cbz' | head -5
```

`HTTP/1.1 206 Partial Content` and a `Content-Range` header means it will work.
A `200` means the host ignored the range.

## Naming

- **Page files sort naturally**, so `2.jpg` correctly comes before `10.jpg`.
  Zero-padding is *not* required — but pad anyway (`001.jpg`) so the files look
  right in every other tool.
- **Chapter numbers** are read from the folder or archive name. All of these
  work: `Chapter 001`, `Ch.12`, `chapter 12.5`, `c007 - The Title`,
  `v02 c013` (volume ignored, chapter used), `005`.
  A name with no number at all (`Extras`, `Omake`) still appears, ordered by
  name.
- **Spaces, parentheses, `!`, `&` and non-ASCII names are all fine** —
  `よつばと！/`, `Oyasumi Punpun (2007)/`, `Tom & Jerry/` all work. Do not
  sanitise names into slugs; the folder name is what the reader sees as the
  title.
- **Avoid trailing spaces** in folder names. They are legal in S3 and invisible
  everywhere, which makes them miserable to debug.

## Covers

Put `cover.jpg` (or `.png` / `.webp`) in the series folder. Optional — without
one the extension falls back to the first page of the first chapter, so covers
always appear either way. Supplying one is faster and usually looks better.

## `details.json`

Optional, goes in the series folder. Every field is optional; with no file the
folder name is the title.

```json
{
  "title": "Blame!",
  "author": "Tsutomu Nihei",
  "artist": "Tsutomu Nihei",
  "description": "In a vast, self-replicating megastructure, a silent wanderer searches for a human carrying the Net Terminal Gene.\n\nThe city grows faster than anyone can cross it.",
  "genre": ["Sci-Fi", "Action", "Cyberpunk"],
  "status": "completed"
}
```

| Field | Accepts |
| --- | --- |
| `title` | Text. Overrides the folder name |
| `author`, `artist` | Text |
| `description` | Text. Use `\n` for line breaks |
| `genre` | A list `["A","B"]` or a string `"A, B"` |
| `status` | `unknown` `ongoing` `completed` `licensed` `publishing finished` `cancelled` `on hiatus`, or the numbers `0`–`6`. Quoted or unquoted, any case |

Unknown keys are ignored, so extra metadata of your own is harmless. `null` and
`""` count as absent. A malformed file is ignored silently and the series falls
back to its folder name — so validate the JSON before uploading.

**`ComicInfo.xml` may be used instead**, placed in the series folder:
`Series`, `Summary`, `Writer`, `Penciller`, `CoverArtist`, `Genre`, `Tags`,
`Status`. If both files exist, `details.json` wins.

Note this is *series-level* metadata. A `ComicInfo.xml` inside a `.cbz` is not
read — opening every archive just to draw the browse screen would be far too
slow. Keep those if other tools use them, but put one copy in the series folder.

## What is ignored or rejected

| Ignored silently | `.DS_Store`, `Thumbs.db`, any dotfile, anything under `__MACOSX/` |
| --- | --- |
| **Not readable** | `.cbr`, `.rar`, `.cb7`, `.7z`, `.cbt`, `.tar`, `.pdf`, `.epub` |

**Renaming a `.cbr` to `.cbz` does not work.** CBR is a RAR archive and CBZ is a
ZIP archive; only the container matters, not the extension. Repack properly:

```bash
mkdir -p tmp && unrar x "Chapter 001.cbr" tmp/ && (cd tmp && zip -r -0 "../Chapter 001.cbz" .) && rm -rf tmp
```

Encrypted or password-protected archives are not supported.

**Usable image formats:** `jpg` `jpeg` `png` `webp` `gif` `avif` `bmp` `jxl`
`heif` `heic`. Extension matching is case-insensitive.

## Uploading

`rclone` is the most reliable tool for R2. Configure once:

```bash
rclone config create r2 s3 \
  provider=Cloudflare \
  access_key_id=YOUR_ACCESS_KEY_ID \
  secret_access_key=YOUR_SECRET_ACCESS_KEY \
  endpoint=https://YOUR_ACCOUNT_ID.r2.cloudflarestorage.com \
  region=auto
```

Then mirror a local folder, preserving the structure exactly:

```bash
rclone copy "./Blame!" "r2:BUCKET/Blame!" --progress --transfers 8
```

Or with the AWS CLI:

```bash
aws s3 sync "./Blame!" "s3://BUCKET/Blame!" \
  --endpoint-url "https://YOUR_ACCOUNT_ID.r2.cloudflarestorage.com"
```

Notes:

- Set sensible `Content-Type`s (`image/jpeg`, `image/png`, …). Both tools do
  this from the file extension. It is not strictly required for the app, but
  matters if the bucket is ever served over a public domain.
- Do not create zero-byte placeholder objects for "folders". S3 has no real
  folders — the path in the key *is* the structure. Placeholders are harmless
  but pointless.
- Uploads are idempotent; re-running fixes a partial upload.

## Check your work

After uploading, confirm:

- [ ] Series folders sit at the top level of the library, not nested deeper
- [ ] Each series contains chapter folders **or** `.cbz` files, not a single
      archive of the whole series
- [ ] Page files inside each chapter, no extra nesting
- [ ] No `.cbr` / `.rar` / `.pdf` left behind
- [ ] Any `details.json` is valid JSON
- [ ] Folder names are the titles you want displayed

The repository's `scripts/probe-bucket.sh` checks all of this against the live
bucket and reports what the app will show. In the app itself, content appears on
refresh, or within the listing cache window (5 minutes by default).
