#!/usr/bin/env bash
#
# Checks a real R2 bucket using the same code the extension runs on the device:
# request signing, bucket listing, metadata parsing and archive reading.
#
# Nothing is written down. The secret key is read from a prompt so it never
# reaches your shell history, and the probe prints only what the credentials
# unlock, never the credentials themselves.
#
# Usage:  scripts/probe-bucket.sh
#         R2_ACCOUNT_ID=... R2_BUCKET=... scripts/probe-bucket.sh   # skip those prompts

set -euo pipefail
cd "$(dirname "$0")/.."

ask() { # ask VAR "prompt" [optional]
  local var=$1 prompt=$2 optional=${3:-} value=${!1:-}
  if [ -z "$value" ]; then
    read -r -p "$prompt" value
  fi
  if [ -z "$value" ] && [ -z "$optional" ]; then
    echo "  $var is required." >&2
    exit 1
  fi
  printf -v "$var" '%s' "$value"
  export "${var?}"
}

echo "R2 bucket probe"
echo

ask R2_ACCOUNT_ID       "Cloudflare account id (or full S3 endpoint): "
ask R2_BUCKET           "Bucket name: "
ask R2_ACCESS_KEY_ID    "Access Key ID: "

if [ -z "${R2_SECRET_ACCESS_KEY:-}" ]; then
  read -r -s -p "Secret Access Key (hidden): " R2_SECRET_ACCESS_KEY
  echo
  export R2_SECRET_ACCESS_KEY
fi

ask R2_ROOT_PREFIX      "Library folder inside the bucket [none]: " optional
ask R2_PUBLIC_BASE_URL  "Public image URL [none]: "                 optional

echo
./gradlew --quiet --console=plain \
  :extension:testReleaseUnitTest --tests '*BucketProbe*' --rerun-tasks
