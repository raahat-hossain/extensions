import org.jetbrains.kotlin.gradle.dsl.JvmTarget
import java.security.MessageDigest

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.serialization)
}

// ---------------------------------------------------------------------------
// Extension metadata. `extVersionCode` must be bumped on every release you want
// the app to offer as an update.
// ---------------------------------------------------------------------------
val extName = "MNG Collection"
val extLang = "all"
val extClass = ".MngCollection"
val extVersionCode = 6
val extIsNsfw = false

// The host app derives the extension API version from `versionName`, by taking
// everything before the last dot. It must stay "1.4" — see ExtensionLoader.
val libVersion = "1.4"
val pkgNameSuffix = "$extLang.mngcollection"
val extPackage = "eu.kanade.tachiyomi.extension.$pkgNameSuffix"
val extVersionName = "$libVersion.$extVersionCode"

/**
 * Mirrors the id generation in the app's `HttpSource`, so the published repo
 * index advertises the same source id the extension will report once installed.
 */
fun sourceId(name: String, lang: String, versionId: Int = 1): Long {
    val bytes = MessageDigest.getInstance("MD5")
        .digest("${name.lowercase()}/$lang/$versionId".toByteArray())
    return (0..7)
        .map { bytes[it].toLong() and 0xff shl (8 * (7 - it)) }
        .reduce(Long::or) and Long.MAX_VALUE
}

// A keystore is only wired up when the environment supplies one (CI). Local
// builds fall back to the debug key so `assembleRelease` always yields an
// installable APK.
val releaseKeystore = System.getenv("KEYSTORE_PATH")
    ?.let(::file)
    ?.takeIf { it.exists() }

android {
    namespace = extPackage
    compileSdk = 35

    defaultConfig {
        applicationId = extPackage
        minSdk = 21
        targetSdk = 35
        versionCode = extVersionCode
        versionName = extVersionName

        manifestPlaceholders["extClass"] = extClass
        manifestPlaceholders["extLabel"] = extName
        manifestPlaceholders["extNsfw"] = if (extIsNsfw) 1 else 0
    }

    signingConfigs {
        if (releaseKeystore != null) {
            create("ext") {
                storeFile = releaseKeystore
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName(
                if (releaseKeystore != null) "ext" else "debug",
            )
        }
    }

    sourceSets {
        named("main") {
            manifest.srcFile("src/main/AndroidManifest.xml")
            kotlin.srcDirs("src/main/kotlin")
            res.srcDirs("src/main/res")
        }
        named("test") {
            kotlin.srcDirs("src/test/kotlin")
        }
    }

    testOptions {
        unitTests.isReturnDefaultValues = true
        unitTests.all { test ->
            // BucketProbe reports through stdout; without this it would be swallowed.
            test.testLogging {
                showStandardStreams = true
                events("skipped", "failed")
                exceptionFormat = org.gradle.api.tasks.testing.logging.TestExceptionFormat.FULL
            }
            // Credentials reach the probe through the environment, never the build files.
            listOf(
                "R2_ENDPOINT", "R2_ACCOUNT_ID", "R2_BUCKET", "R2_ACCESS_KEY_ID",
                "R2_SECRET_ACCESS_KEY", "R2_REGION", "R2_ROOT_PREFIX", "R2_PUBLIC_BASE_URL",
            ).forEach { name ->
                System.getenv(name)?.let { test.environment(name, it) }
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }

    dependenciesInfo {
        includeInApk = false
        includeInBundle = false
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_1_8)
        freeCompilerArgs.add("-opt-in=kotlinx.serialization.ExperimentalSerializationApi")
    }
}

base {
    archivesName.set("tachiyomi-$pkgNameSuffix-v$extVersionName")
}

dependencies {
    // Every one of these ships inside the host app; the extension must not
    // bundle its own copies.
    compileOnly(libs.bundles.common)

    // compileOnly does not reach the unit-test classpath, so repeat it there.
    testImplementation(libs.bundles.common)
    testImplementation(libs.junit)
}

/**
 * Emits the entry the app's extension-repo index is built from, so CI does not
 * have to re-parse this file. See `.github/workflows/build.yml`.
 */
tasks.register("extensionMetadata") {
    val outFile = layout.buildDirectory.file("extension-metadata.json")
    outputs.file(outFile)
    doLast {
        val json = """
            {
              "name": "$extName",
              "pkg": "$extPackage",
              "apk": "tachiyomi-$pkgNameSuffix-v$extVersionName.apk",
              "lang": "$extLang",
              "code": $extVersionCode,
              "version": "$extVersionName",
              "nsfw": ${if (extIsNsfw) 1 else 0},
              "sources": [
                {
                  "name": "$extName",
                  "lang": "$extLang",
                  "id": "${sourceId(extName, extLang)}",
                  "baseUrl": ""
                }
              ]
            }
        """.trimIndent()
        val file = outFile.get().asFile
        file.parentFile.mkdirs()
        file.writeText(json)
        println(json)
    }
}
